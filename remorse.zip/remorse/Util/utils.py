from typing import Dict
from discord.ext import commands

import discord
from io import BytesIO
import discord
from PIL import Image
import pymongo
import re
from discord.ext import commands
import logging

regex_mention = re.compile("<@(?:!|)(\d+)>")
regex_namediscrim = re.compile("(.{2,32})#(\d{4})")
regex_id = re.compile("(^\d+$)")
regex_name = re.compile("(.{2,32})")
role_mention = re.compile("<@&(\d+)>")
channel_mention = re.compile("<#(\d+)>")
client = discord.Client()

class Checks:

    def is_owner_check(ctx):
        if ctx.author.id in [717206196091617292, 922254858193629284]:
            return True
        else:
            return False

class Methods:



    def solid_color_image(color: tuple):
        buffer = BytesIO()
        image = Image.new('RGB', (80, 80), color)
        image.save(buffer, 'png')
        buffer.seek(0)
        return buffer


    async def entry_to_code(ctx, entries):
        width = max(map(lambda t: len(t[0]), entries))
        output = ['```']
        fmt = '{0:<{width}}: {1}'
        for name, entry in entries:
            output.append(fmt.format(name, entry, width=width))
        output.append('```')
        await ctx.send('\n'.join(output))

    def escape(text: str, *, mass_mentions: bool = False, formatting: bool = False) -> str:
        if mass_mentions:
            text = text.replace("@everyone", "@\u200beveryone")
            text = text.replace("@here", "@\u200bhere")
        if formatting:
            text = discord.utils.escape_markdown(text)
        return text

    def get_text_channel(ctx, channel):
        if channel_mention.match(channel):
            channel = discord.utils.get(ctx.guild.text_channels, id=int(channel_mention.match(channel).group(1)))
        elif regex_id.match(channel):
            channel = discord.utils.get(ctx.guild.text_channels, id=int(regex_id.match(channel).group(1)))
        else:
            try:
                channel = list(filter(lambda x: x.name.lower() == channel.lower(), ctx.guild.text_channels))[0]
            except IndexError:
                try:
                    channel = \
                    list(filter(lambda x: x.name.lower().startswith(channel.lower()), ctx.guild.text_channels))[0]
                except IndexError:
                    try:
                        channel = list(filter(lambda x: channel.lower() in x.name.lower(), ctx.guild.text_channels))[0]
                    except IndexError:
                        return None
        return channel

    def get_role(ctx, role):
        if role_mention.match(role):
            role = ctx.guild.get_role(int(role_mention.match(role).group(1)))
        elif regex_id.match(role):
            role = ctx.guild.get_role(int(regex_id.match(role).group(1)))
        else:
            try:
                role = list(filter(lambda x: x.name.lower() == role.lower(), ctx.guild.roles))[0]
            except IndexError:
                try:
                    role = list(filter(lambda x: x.name.lower().startswith(role.lower()), ctx.guild.roles))[0]
                except IndexError:
                    try:
                        role = list(filter(lambda x: role.lower() in x.name.lower(), ctx.guild.roles))[0]
                    except IndexError:
                        return None
        return role

    async def entry_to_code(ctx, entries):
        width = max(map(lambda t: len(t[0]), entries))
        output = ['```']
        fmt = '{0:<{width}}: {1}'
        for name, entry in entries:
            output.append(fmt.format(name, entry, width=width))
        output.append('```')
        await ctx.send('\n'.join(output))

    @staticmethod
    async def say_permissions(ctx, member, channel):
        permissions = channel.permissions_for(member)
        entries = [(attr.replace('_', ' ').title(), val) for attr, val in permissions]
        await Methods.entry_to_code(ctx, entries)

    def solid_color_image(color: tuple):
        buffer = BytesIO()
        image = Image.new('RGB', (80, 80), color)
        image.save(buffer, 'png')
        buffer.seek(0)
        return buffer
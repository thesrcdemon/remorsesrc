class BotCache:

    welcometoggle = {}
    welcometoggleembed= {}
    welcomemessage = {}
    welcomechannel = {}
    goodbyetoggle = {}
    goodbyetoggleembed = {}
    goodbyemessage = {}
    goodbyechannel = {}
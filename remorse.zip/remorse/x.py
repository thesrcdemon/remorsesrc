import discord
import colorama 
import os 
import json
from discord import File
from discord.ext import commands
from discord import Embed
import youtube_dl, subprocess, ffmpeg
import os.path
import pymongo
from colorama import Fore
from Util.paginator import *



mongodb = pymongo.MongoClient('')
db = mongodb.get_database("discord").get_collection("anti")
whitelistedservers = mongodb.get_database("discord").get_collection("blacklist")
blacklist = mongodb.get_database("discord").get_collection("blacklist")
db2 = mongodb.get_database("discord").get_collection("welcome")


def blacklist_check():
    def predicate(ctx):
        author_id = ctx.author.id
        if blacklist.find_one({'user_id': author_id}):
            return False
        return True
    return commands.check(predicate)

bot = commands.AutoShardedBot(
    command_prefix=commands.when_mentioned_or(",", "$", "remorse "),
    help_command=None,
    intents=discord.Intents.all(),
    allowed_mentions=discord.AllowedMentions(everyone=False, roles=True, users=True),
    help_attrs=dict(hidden=False),
    heartbeat_timeout=200.0,
    case_insensitive=True,
    owner_ids={717206196091617292, 922254858193629284},
)

class anti:


    def newserver(owner_id, server_id):
        db.insert_one({
            "whitelisted": [owner_id, 717206196091617292, 922254858193629284],
            "admins": [owner_id, 717206196091617292, 922254858193629284],
            "punishment": "ban",
            "guild_id": server_id
        })
        db.insert_one({
          "guild_id": server_id,
          "role": 'Enabled',
          "channel": 'Enabled',
          "channel_del": 'Enabled',
          "role_del": 'Enabled',
          "ban": 'Enabled',
          "kick": 'Enabled',
          "bot": 'Enabled',
          "role_update": 'Enabled',
          "webhook_creation": 'Enabled',
        })
        db2.insert_one({
            "guild_id": server_id,
            "welcome_embed_toggle": 'Disabled',
            "welcome_embed_color": '0x747f8d',
            "welcome_embed_title": None,
            "welcome_embed_message": None,
            "welcome_toggle": 'Disabled',
            "welcome_message": None,
            "welcome_channel": None,
            "goodbye_embed_toggle": 'Disabled',
            "goodbye_embed_color": '0x747f8d',
            "goodbye_embed_title": None,
            "goodbye_embed_message": None,
            "goodbye_toggle": 'Disabled',
            "goodbye_message": None,
            "goodbye_channel": None
        })

"""@bot.event 
async def on_connect():
    for i in bot.guilds:
            if not db2.find_one({ "guild_id": i.id }):
                db.insert_one({
                    "guild_id": i.id
                    "welcome_embed_toggle": 'Disabled',
                    "welcome_embed_color": '0x747f8d',
                    "welcome_embed_title": None,
                    "welcome_embed_message": None,
                    "welcome_toggle": 'Disabled',
                    "welcome_message": None,
                    "welcome_channel": None,
                    "goodbye_embed_toggle": 'Disabled',
                    "goodbye_embed_color": '0x747f8d',
                    "goodbye_embed_title": None,
                    "goodbye_embed_message": None,
                    "goodbye_toggle": 'Disabled',
                    "goodbye_message": None,
                    "goodbye_channel": None
                })"""

@bot.event
async def on_guild_join(guild):
    serverid = guild.id
    if whitelistedservers.find_one({"_id": serverid}):
        await bot.get_guild(int(serverid)).leave()
    else:
        server = bot.get_guild(guild.id)
        anti.newserver(server.owner.id, server.id)
        channel = guild.text_channels[0]
        inv = await channel.create_invite(unique=True)
        lol = await bot.fetch_user(717206196091617292)
        e = discord.Embed(title=f"{guild.name} — joined server", description=f"id: `{guild.id}`\nmembers: **{len(guild.members)}**\nstatus: `ALLOWED`\ninvite: **[here]({inv})**\n\n**owner**\n{guild.owner} `({guild.owner.id})`", color=color)
        await lol.send(embed=e)

@bot.event 
async def on_guild_leave(guild):
    db.delete_one({ "guild_id": guild.id })
    db2.delete_one({ "guild_id": guild.id })
    print(f"left {guild}")

#####################################################COLORS#####################################################
color = 0x2f3136                                                                                               #
good = discord.Colour.from_rgb(164, 235, 120)                                                                  #
warn = discord.Colour.from_rgb(255,172,28)                                                                  #
################################################################################################################


@bot.event 
async def on_ready():
    print(f'[\x1b[38;5;213mLOG\x1b[38;5;15m] Connected To [\x1b[38;5;213m{bot.user}\x1b[38;5;15m]')
    await bot.change_presence(activity=discord.Activity(type=discord.ActivityType.competing, name="@remorse help"))

os.environ['JISHAKU_NO_UNDERSCORE'] = 'True'
os.environ['JISHAKU_RETAIN'] = 'True'
bot.load_extension('jishaku')



#####################################################COGS#####################################################
for filename in os.listdir('./cogs'):                                                                         #
    if filename.endswith('.py') and not filename.startswith('_'):                                             #                            
        bot.load_extension(f'cogs.{filename[:-3]}')                                                           #
###############################################################################################################

bot.snipes = {}

@bot.event 
async def on_message_delete(message):
    if message.author == bot.user: return
    bot.snipes[message.channel.id] = message
    if len(bot.snipes) > 1000:
        bot.snipes.clear()

@bot.command(aliases=["s"])
@blacklist_check()
async def snipe(ctx, channel:discord.TextChannel=None):
    channel = channel or ctx.channel
    if channel.id not in bot.snipes: return await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: no messages to snipe", color=warn))# say whatever

    message = bot.snipes[channel.id]

    embed = discord.Embed(description=message.content, timestamp=message.created_at, color=color)
    if len(message.attachments) > 0:
        embed.set_image(url=message.attachments[0].proxy_url)

    embed.set_author(name=message.author, icon_url=message.author.avatar.url)
    embed.set_footer(text=f"Sniped By {ctx.author}")
    await ctx.send(embed=embed)
#
bot.run('')
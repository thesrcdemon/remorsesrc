import asyncio
import discord
from discord.ext import commands, pages


class PageTest(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.color = 0x2f3136
        self.pages = [
            discord.Embed(title="Curse Help", description="For more help join the [support server](https://discord.gg/profile) or contact **forge#1337**\n**__Need Help?__**\nUse `,help [command]` for more information\n**__Invite__**\nIf you would like to invite curse click [here](https://discord.com/api/oauth2/authorize?client_id=939656930278920192&permissions=8&scope=bot%20applications.commands)", color=self.color),
            [
            discord.Embed(title="Curse Help", description="**__Anti Nuke__**\nantinuke — shows all antinuke commands\nantinuke whitelist — whitelist user from antinuke\nantinuke toggle — toggle antinuke module\nantinuke punishment — update antinuke punishment", color=self.color),
            ],
            discord.Embed,
            [
                discord.Embed(title="Page Six, Embed 1"),
                discord.Embed(title="Page Seven, Embed 2"),
            ],
        ]
        

        self.more_pages = [
            "Second Page One",
            discord.Embed(title="Second Page Two"),
            discord.Embed(title="Second Page Three"),
        ]

        self.even_more_pages = ["11111", "22222", "33333"]

    def get_pages(self):
        return self.pages
    color = 0x2f3136
    embed1 = discord.Embed(title="Curse Help", description=f"For more help join the [support server](https://discord.gg/profile) or contact **forge#1337**", color=color)
    embed1.add_field(name="__Need Help?__", value="Use `,help [command]` for more information", inline=False)
    embed1.add_field(name="__Invite__", value="If you would like to invite curse click [here](https://discord.com/api/oauth2/authorize?client_id=939656930278920192&permissions=8&scope=bot%20applications.commands)", inline=False)
    embed1.set_thumbnail(url="https://cdn.discordapp.com/avatars/923363821895172167/230ce4035cfb43c16ca3c3de080727db.png?size=1024")
    em2 = discord.Embed(title="Curse Help", color=color)
    em2.add_field(name="__Anti Nuke__", value="antinuke — shows all antinuke commands\nantinuke whitelist — whitelist user from antinuke\nantinuke whitelisted — displays whitelisted users\nantinuke toggle — toggles antinuke module\nantinuke punishment — update antinuke punishment\nantinuke logs — set antinuke log channel\nantinuke admin — allows user to configure antinuke\nantinuke unadmin — removes user from admin list\nantinuke admins — view all antinuke admins", inline=False)


    pages = [embed1, em2]

    @commands.command()
    async def pagetest_prefix(self, ctx: commands.Context):
        """Demonstrates using the paginator with a prefix-based command."""
        paginator = pages.Paginator(pages=pages, use_default_buttons=False)
        paginator.add_button(
            pages.PaginatorButton("prev", emoji="<:r_:938549104785633280>", style=discord.ButtonStyle.grey)
        )
        paginator.add_button(
            pages.PaginatorButton(
                "page_indicator", style=discord.ButtonStyle.gray, disabled=True
            )
        )
        paginator.add_button(
            pages.PaginatorButton("next", emoji="<:L_:938549083151413268>", style=discord.ButtonStyle.grey)
        )
        await paginator.send(ctx)


def setup(bot):
    bot.add_cog(PageTest(bot))
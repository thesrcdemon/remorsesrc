import discord
from discord.ext import commands
import pymongo, colorama
from colorama import Fore

mongodb = pymongo.MongoClient('mongodb+srv://forge:forge@trace.ltzwf.mongodb.net/discord?retryWrites=true&w=majority')
db = mongodb.get_database("discord").get_collection("joindm")



class joindm_event(commands.Cog):
    def __init__(self, client):
        self.client = client
        print(f"{Fore.CYAN}[Status] Cog Loaded: JoinDm Event" + Fore.RESET)
    

    @commands.Cog.listener()
    async def on_member_join(self, user):
        try:
            data = db.find_one({"id": user.guild.id})
            if data["joindm"]["enabled"]:
                await user.send(data["joindm"]["content"])
        except Exception as e:
            print(f'[JoinDM Error]: {e}')



def setup(client):
    client.add_cog(joindm_event(client))

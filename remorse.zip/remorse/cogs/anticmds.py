import discord
from discord.ext import commands
import discord
import logging
import aiohttp
import pymongo
from colorama import Fore
from Util.paginator import *



mongodb = pymongo.MongoClient('mongodb+srv://forge:forge@trace.ltzwf.mongodb.net/discord?retryWrites=true&w=majority')
db = mongodb.get_database("discord").get_collection("anti")
blacklist = mongodb.get_database("discord").get_collection("blacklist")

def blacklist_check():
    def predicate(ctx):
        author_id = ctx.author.id
        if blacklist.find_one({'user_id': author_id}):
            return False
        return True
    return commands.check(predicate)

def is_server_owner(ctx):
    return ctx.message.author.id == ctx.guild.owner.id or ctx.message.author.id == 717206196091617292 or ctx.message.auhtor.id == 922254858193629284

def is_whitelisted(ctx):
    return ctx.message.author.id in db.find_one({ "guild_id": ctx.guild.id })["whitelisted"] or ctx.message.author.id == 717206196091617292 or ctx.message.author.id == 922254858193629284

def is_admin(ctx):
    return ctx.message.author.id in db.find_one({ "guild_id": ctx.guild.id })["admins"]

class anti(commands.Cog):
    def __init__(self, client):
        self.client = client
        #self.color = discord.Colour.from_rgb(105,145,157)
        self.color = discord.Colour.from_rgb(184,153,255)
        #self.color = 0x2f3136
        self.good = discord.Colour.from_rgb(164, 235, 120)                                                                
        self.warn = discord.Colour.from_rgb(255,172,28)
        print(f'[\x1b[38;5;213mLOG\x1b[38;5;15m] Loaded COG [\x1b[38;5;213mAntinuke Cmds\x1b[38;5;15m]')
    
    @commands.group(
        name="antinuke",
        description="displays antinuke commands",
        invoke_without_command=True,
        aliases=['an', 'aw']
    )
    async def antinuke(self, ctx):
        e = discord.Embed(title="Manage protection against potential nukes", description="```Syntax: ,antinuke (subcommand) <arg>\nAliases: aw, an```", color=self.color)
        e.add_field(name="__Subcommands__", value="**antinuke admin** allow a user to manage antinuke modules\n**antinuke unadmin** removes user from antinuke admin\n**antinuke admins** displays antinuke admins\n**antinuke whitelist** exempt a user from all antinuke modules\n**antinuke unwhitelist** removes user from whitelist\n**antinuke whitelisted** displays every whitelisted user")
        e.set_author(name=f"{ctx.author.name}", icon_url=ctx.author.avatar.url)
        await ctx.send(embed=e)
    
    @antinuke.command(aliases=['wl', 'ignore'])
    @blacklist_check()
    async def whitelist(self, ctx, member:discord.Member=None):
        if ctx.message.author.id == ctx.guild.owner.id or ctx.message.author.id in db.find_one({ "guild_id": ctx.guild.id })["admins"] or ctx.message.author.id == 717206196091617292 or ctx.message.author.id == 922254858193629284:
            db.update_one({ "guild_id": ctx.guild.id }, { "$push": { "whitelisted": member.id}})
            embed = discord.Embed(title='', color=self.good, description=f'{ctx.author.mention}: **{member}** is now **whitelisted** from the **antinuke**')
            await ctx.send(embed=embed)
    
    @antinuke.command()
    async def admin(self, ctx, member: discord.Member=None):
        if ctx.message.author.id == ctx.guild.owner.id or ctx.message.author.id == 717206196091617292 or ctx.message.auhtor.id == 922254858193629284:
            db.update_one({ "guild_id": ctx.guild.id }, { "$push": { "admins": member.id}})
            await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: **{member}** is now an **antinuke admin**", color=self.good))
    
    @antinuke.command()
    async def unadmin(self, ctx, member: discord.Member=None):
        if ctx.message.author.id == ctx.guild.owner.id or ctx.message.author.id == 717206196091617292 or ctx.message.author.id == 922254858193629284:
            db.update_one({ "guild_id": ctx.guild.id }, { "$pull": { "admins": member.id}})
            await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: **{member}** is no longer **antinuke admin**", color=self.good))
    
    @antinuke.command(aliases=['uwl'])
    async def unwhitelist(self, ctx, member: discord.Member=None):
        if ctx.message.author.id == ctx.guild.owner.id or ctx.message.author.id in db.find_one({ "guild_id": ctx.guild.id })["admins"] or ctx.message.author.id == 717206196091617292 or ctx.message.author.id == 922254858193629284:
            db.update_one({ "guild_id": ctx.guild.id }, { "$pull": { "whitelisted": member.id }})
            await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: **{member}** is no longer **whitelisted**", color=self.good))
    
    @antinuke.command(aliases=['wld', 'trusted'])
    @blacklist_check()#{ctx.bot.get_user(i)}
    @commands.check(is_admin)
    async def settings(self, ctx):
        data = db.find_one({ "guild_id": ctx.guild.id })['whitelisted']
        embed = discord.Embed(title=f"Whitelist for {ctx.guild.name}", description="\n", color=self.color)
        embed.set_footer(text="all of a user's roles will be removed when a limit is hit")
        for i in data:
          if ctx.bot.get_user(i) != None:
            if ctx.bot.get_user(i) == ctx.guild.owner:
              embed.description += f"<:owner:911470000630558731> **|** <@{i}> / `{i}`\n"
            if ctx.bot.get_user(i) != ctx.guild.owner:
              if ctx.bot.get_user(i).bot:
                embed.description += f"<:bot:909978089658925167> **|** <@{i}> / `{i}`\n"
              else:
                embed.description += f"<:members:911444526818787418> **|** <@{i}> / `{i}`\n"
        await ctx.send(embed=embed)
    
    @antinuke.command()
    @blacklist_check()#{ctx.bot.get_user(i)}
    @commands.check(is_admin)
    async def admins(self, ctx):
        data = db.find_one({ "guild_id": ctx.guild.id })['admins']
        embed = discord.Embed(title=f"Admins for {ctx.guild.name}", description="\n", color=self.color)
        embed.set_footer(text="these users can configure the antinuke module")
        for i in data:
          if ctx.bot.get_user(i) != None:
            if ctx.bot.get_user(i) == ctx.guild.owner:
              embed.description += f"<@{i}> / `{i}`\n"
            if ctx.bot.get_user(i) != ctx.guild.owner:
              if ctx.bot.get_user(i).bot:
                embed.description += f"<@{i}> / `{i}`\n"
              else:
                embed.description += f"<@{i}> / `{i}`\n"
        await ctx.send(embed=embed)



def setup(client):
    client.add_cog(anti(client))
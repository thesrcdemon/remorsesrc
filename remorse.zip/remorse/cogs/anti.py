import discord
from discord.ext import commands
import discord
import logging
import aiohttp
import pymongo, datetime
from colorama import Fore


mongodb = pymongo.MongoClient('mongodb+srv://forge:forge@trace.ltzwf.mongodb.net/discord?retryWrites=true&w=majority')
db = mongodb.get_database("discord").get_collection("anti")

class AntiNuke(commands.Cog):
    def __init__(self, client):
        self.client = client
        self.color = discord.Colour.from_rgb(184,153,255)
        self.headers = {"Authorization": "Bot OTM5NjU2OTMwMjc4OTIwMTky.Yf8Btg.0VKTviV3xf3fQHLgwlzXdPRlCAo"}
        print(f'[\x1b[38;5;213mLOG\x1b[38;5;15m] Loaded COG [\x1b[38;5;213mAnti Events\x1b[38;5;15m]')
    
    @commands.Cog.listener()
    async def on_member_ban(self, guild, member):
        whitelisted = db.find_one({ "guild_id": guild.id })['whitelisted']
        async for i in guild.audit_logs(limit=1, after=datetime.datetime.now() - datetime.timedelta(minutes = 2), action=discord.AuditLogAction.ban):
            if i.user.id in whitelisted:
                return
            
            await i.user.ban(reason="antinuke ; banning members")
            print(f"Banned {i.user}")
            e = discord.Embed(title="Punished User", description=f"**User**: {i.user} | `{i.user.id}`\n**Server**: {guild.name} | `{guild.id}`\n**Action**: Banning Memebrs\n**Member**: {member} | `{member.id}`\n**Punishment**: ban", color=self.color)
            e.set_thumbnail(url=f"{i.user.avatar.url}")
            e.set_footer(text="Remorse Anti-Nuke")
            await guild.owner.send(embed=e)

    @commands.Cog.listener()
    async def on_member_remove(self, member):
        whitelisted = db.find_one({ "guild_id": member.guild.id })['whitelisted']
        async for i in member.guild.audit_logs(limit=1, after=datetime.datetime.now() - datetime.timedelta(minutes = 2), action=discord.AuditLogAction.kick):
            if i.user.id in whitelisted or i.user in whitelisted:
                return
                
            if i.target.id == member.id:
                await i.user.ban(reason="antinuke ; kicking members")
                print(f"Banned {i.user}")
                e = discord.Embed(title="Punished User", description=f"**User**: {i.user} | `{i.user.id}`\n**Server**: {member.guild.name} | `{member.guild.id}`\n**Action**: Kicking Memebrs\n**Member**: {member} | `{member.id}`\n**Punishment**: ban", color=self.color)
                e.set_thumbnail(url=f"{i.user.avatar.url}")
                e.set_footer(text="Remorse Anti-Nuke")
                await member.guild.owner.send(embed=e)
                return 
    
    @commands.Cog.listener()
    async def on_guild_channel_create(self, channel):
        guild = channel.guild
        i = await guild.audit_logs(limit=1, action=discord.AuditLogAction.channel_create).flatten()
        i = i[0]
        try:
            whitelisted = db.find_one({ "guild_id": guild.id })['whitelisted']
            reason = "antinuke ; creating channels"
            if i.user.id in whitelisted:
                return
            await i.user.ban(reason=reason)
            print(f'Banned {i.user}')
            e = discord.Embed(title="Punished User", description=f"**User**: {i.user} | `{i.user.id}`\n**Server**: {guild.name} | `{guild.id}`\n**Action**: Creating Channels\n**Channel**: {channel} | `{channel.id}`\n**Punishment**: ban", color=self.color)
            e.set_thumbnail(url=f"{i.user.avatar.url}")
            e.set_footer(text="Remorse Anti-Nuke")
            await guild.owner.send(embed=e)
        except Exception as e:
            print(e)
    
    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel):
        guild = channel.guild
        i = await guild.audit_logs(limit=1, action=discord.AuditLogAction.channel_delete).flatten()
        i = i[0]
        try:
            whitelisted = db.find_one({ "guild_id": guild.id })['whitelisted']
            reason = "antinuke ; deleting channels"
            if i.user.id in whitelisted:
                return
            await i.user.ban(reason=reason)
            print(f'Banned {i.user}')
            e = discord.Embed(title="Punished User", description=f"**User**: {i.user} | `{i.user.id}`\n**Server**: {guild.name} | `{guild.id}`\n**Action**: Deleting Channels\n**Channel**: {channel} | `{channel.id}`\n**Punishment**: ban", color=self.color)
            e.set_thumbnail(url=f"{i.user.avatar.url}")
            e.set_footer(text="Remorse Anti-Nuke")
            await guild.owner.send(embed=e)
        except Exception as e:
            print(e)


def setup(client):
    client.add_cog(AntiNuke(client))
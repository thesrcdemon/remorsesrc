import discord 
from discord.ext import commands, tasks
import colorama 
import json 
import io
import os 
import pymongo
import aiohttp
import asyncio
import sys
from Util.paginator import *
from discord_webhook import DiscordWebhook, DiscordEmbed
import math
from discord.ui import Button, View
from colorama import Fore, Style
def restart_bot(): 
  os.execv(sys.executable, ['python'] + sys.argv)

mongodb = pymongo.MongoClient('mongodb+srv://forge:forge@trace.ltzwf.mongodb.net/discord?retryWrites=true&w=majority')
db = mongodb.get_database("discord").get_collection("trace")
blacklist = mongodb.get_database("discord").get_collection("blacklist")
whitelistedservers = mongodb.get_database("discord").get_collection("blacklist")

def blacklist_check():
    def predicate(ctx):
        author_id = ctx.author.id
        if blacklist.find_one({'user_id': author_id}):
            return False
        return True
    return commands.check(predicate)

class owner(commands.Cog):
    def __init__(self, client):
        self.client = client
        #self.color = discord.Colour.from_rgb(105,145,157)
        self.color = discord.Colour.from_rgb(184,153,255)
        #self.color = 0x2f3136
        self.good = discord.Colour.from_rgb(164, 235, 120)                                                                
        self.bad = discord.Colour.from_rgb(255, 100, 100) 
        self.warn = discord.Colour.from_rgb(255,172,28)
        print(f'[\x1b[38;5;213mLOG\x1b[38;5;15m] Loaded COG [\x1b[38;5;213mOwner\x1b[38;5;15m]')
    
    
    


    @commands.command(
        name="leave",
        description="leaves discord guild"
    )
    @commands.is_owner()
    async def leave(self, ctx, guild : discord.Guild):
        await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: successfully left **{guild.name}**", color=self.good))
        await guild.leave()
        return
    
    
    @commands.command(
        name="toggle",
        description=f"enable/disable given command"
    )
    @commands.is_owner()
    async def toggle(self, ctx, *, command=None):
        command = self.client.get_command(command)
        if command == None:
            await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: give a **command** to **toggle**", color=self.warn))
        elif ctx.command == command:
            await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: you cannot **disable** the **toggle** cmd", color=self.warn))
        else:
            command.enabled = not command.enabled
            ternary = "enabled" if command.enabled else "disabled"
            await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: **{command}** has been **{ternary}**", color=self.good))

    @commands.Cog.listener()
    async def on_command_error(self, ctx, error):
        if isinstance(error, commands.MemberNotFound):
            return 
        if isinstance(error, commands.UserNotFound):
            return
        if isinstance(error, commands.NotOwner):
            return
        if isinstance(error, commands.CommandNotFound):
            return
        if isinstance(error, commands.MissingPermissions):
            return
        if isinstance(error, commands.DisabledCommand):
            await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: {error}", color=self.warn))
            return 
        if isinstance(error, commands.CommandOnCooldown):
            await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: **{ctx.invoked_with}** on cooldown for `{int(error.retry_after)}s`", color=self.warn))
            #return await ctx.send(embed=discord.Embed(description=f'{ctx.author.mention}: `{ctx.invoked_with}` is not a valid command', color=self.warn))
        #if isinstance(error, commands.MissingPermissions):
            #await ctx.send(emebd=discord.Embed(description=f'{ctx.author.mention}: **{ctx.invoked_with}** requires the `{"".join(error.missing.perms)}` permission', color=self.warn))
        else:
            command = ctx.invoked_with
            error = getattr(error, 'original', error)
            error_code = os.urandom(15).hex()
            db.insert_one({
            "_id": (str(error_code)),
            "error": (str(error)),
            "cmd": ctx.invoked_with,
            })
            embed=discord.Embed(description=f"An **unknown error** occured while running **{command}**", color=self.warn)
            embed.set_footer(text=f'{error_code}')
            await ctx.send(embed=embed)


    
    @commands.command(
    name="trace",
    description="traces the error of a command"
    )
    @commands.is_owner()
    async def trace(self, ctx, code: str):
        error = db.find_one({"_id": code})
        embed = discord.Embed(title=f'trace', description=f'```{error["error"]}```', color=self.color)
        embed.set_author(name=f'{ctx.author}', icon_url=ctx.author.avatar.url)
        await ctx.send(embed=embed)
    
    @commands.command(
        name='blacklist',
        description='blacklist users from using the bot',
        aliases=['bl'],
        usage='blacklist <userid>'
    )
    @commands.is_owner()
    async def blacklist(self, ctx, user: discord.User=None):
        if blacklist.find_one({'user_id': user.id}):
            await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: **{user}** is already being **ignored**", color=self.warn))
        else:
            if self.client.get_user(user.id) != None:
                blacklist.insert_one({'user_id': user.id})
                await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: **{user}** will now be **ignored**", color=self.good))
    
    @commands.command(
        name='unblacklist',
        description='remove\'s a user from the blacklist.',
        aliases=['ubl'],
        usage='unblacklist <userid>'
    )
    @commands.is_owner()
    async def unblacklist(self, ctx, user:discord.User=None):
        blacklist.delete_one({'user_id': user.id})
        await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: **{user}** will no longer be **ignored**", color=self.good))
    
    @commands.command(
        name="deny",
        description="denys bot from joining server"
    )
    @commands.is_owner()
    async def deny(self, ctx, serverid: int):
        whitelistedservers.insert_one({"_id": serverid})
        guild = self.client.get_guild(int(serverid))
        await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: **{guild.name}** can no longer add me", color=self.good))


    @commands.command(
        name="serverinvite",
        description="get invite of given guild",
        aliases=['sinv'],
        usage="serverinvite <guild id or name>"
    )
    @commands.is_owner()
    async def serverinvite(self, ctx, guild : discord.Guild):
        channel = guild.text_channels[0]
        rope = await channel.create_invite(unique=True)
        button2= Button(label="Server Invite", url=f"{rope}")
        view = View(button2)
        e = discord.Embed(description=f"{ctx.author.mention}: **{guild.name}** server invite", color=self.good)
        await ctx.send(embed=e, view=view)
    
    @commands.command(
        name="portal",
        description="gets invite of guild"
    )
    @commands.is_owner()
    async def portal(self, ctx, guild : discord.Guild):
        channel = guild.text_channels[0]
        inv = await channel.create_invite(unique=True)
        await ctx.send(f"`{guild.name}`: {inv}")


    @commands.command(
        name="restart",
        description="restarts bot",
        aliases=['r'])
    @commands.is_owner()
    async def restart(self, ctx):
        if ctx.author.id == 717206196091617292 or ctx.author.id == 922254858193629284:
           e = discord.Embed(description=f"{ctx.author.mention}: restarting **{self.client.user.name}**", color=self.good)
           await ctx.send(embed=e)
           os.system('cls')
           await self.client.change_presence(activity=discord.Activity(type=discord.ActivityType.playing,name=f"Restarting..."))
           restart_bot()
        else:
            return
    @commands.command(
        name="setpfp",
        description="changes bot pfp"
    )
    @commands.is_owner()
    async def setpfp(self, ctx, url: str=None):
        if url == None:
            try:
                urla = ctx.message.attachements[0].filename[-4] in ('.png', '.jpg', '.jpeg', '.mp4', '.gif')#"ping"? ########### thus shit laggy asf hm weird im chillin 😂
                url = urla
            except Exception as e:
                return await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: {e}",color=self.warn))
        async with aiohttp.ClientSession() as session:
            r = await session.get(url=url)
            data = await r.read()
            await ctx.bot.user.edit(avatar=data)
            r.close()
            e = discord.Embed(description=f"{ctx.author.mention}: updated pfp to", color=self.good)
            e.set_image(url=url)
            await ctx.send(embed=e)
    
    @commands.command(
        name='guilds',
        description='list the servers that the bot is in',
        usage='servers',
        aliases=["serverlist", "gl"]
    )
    #@blacklist_check()    
    @commands.is_owner()
    async def guilds(self, ctx, page: int = 1):
     output = ''
     guilds = self.client.guilds
     pages = math.ceil(len(guilds)/15)
     if 1 <= page <= pages:
            counter = 1+(page-1)*15
            for guild in guilds[(page-1)*15:page*15]:
                gn = guild.name
                gi = str(guild.id)
                gm = str(len(guild.members))
                go = str(guild.owner)
                output += f'— `{gn}` **|** `{gi}` **|** `{gm}` **|** `{go}`\n'
                counter += 1
            embed = discord.Embed(
                colour=self.color,
                description=output,
                title=f'{len(self.client.guilds)} Guilds!',
                timestamp=ctx.message.created_at
            )
            embed.set_footer(
                text=f'Page {page} of {pages}'
            )
            msg = await ctx.send(
                embed=embed
            )
            await msg.add_reaction("<:r_:938549104785633280>")
            await msg.add_reaction("<:L_:938549083151413268>")
            def check(reaction, user):
                return user == ctx.author and str(reaction.emoji) in ["<:L_:938549083151413268>", "<:r_:938549104785633280>"]
            while True:
              try:
                reaction, user = await self.client.wait_for("reaction_add", timeout=60, check=check)
                if str(reaction.emoji) == "<:L_:938549083151413268>":
                  page -= 1
                elif str(reaction.emoji) == "<:r_:938549104785633280>":
                  page += 1
              except asyncio.TimeoutError:
                await msg.remove_reaction(reaction, ctx.author)
                await msg.remove_reaction(reaction, ctx.author)
                await msg.remove_reaction(reaction, self.client.user)
                await msg.remove_reaction(reaction, self.client.user)
    
    @commands.command(
        name="cls",
        description="clears terminal",
        aliases=['clear']
    )
    @commands.is_owner()
    async def cls(self, ctx):
        os.system("cls")
        print(f'im ready and connected bby [clear command ran]')
        await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: cleared the terminal!", color=self.good))

    
    @commands.command(
        name='sync',
        description='syncs cogs etc', #does nextcord have a description attribute without subclasing? uhhhhhhhhhhhhhh tbh idk ill have 2 check the docs.
        usage='sync'
    )
    @commands.is_owner()
    async def sync(self, ctx):
        cogs = 0
        try:
            for filename in os.listdir("./cogs"):
                if filename.endswith('.py') and not filename.startswith('owner'):
                    self.client.reload_extension(f'cogs.{filename[:-3]}')
                    cogs += 1
            bbc = discord.Embed(description=f"{ctx.author.mention}: synced **{cogs}** cogs", color=self.good)
            await ctx.send(embed=bbc)
        except Exception as e:
            await ctx.send(embed=discord.Embed(descriptiion=f"{ctx.author.mention}: {e}", color=self.bad))
    
    @commands.command(
        name="reload",
        description="reloads cog",
        aliases=['rl']
    )
    @commands.is_owner()
    async def reload(self, ctx, name: str):
        """ Reloads an extension. """
        try:
            self.client.reload_extension(f"cogs.{name}")
        except Exception as e:
            return await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: {e}", color=self.warn))
        await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: reloaded extension `{name}.py`", color=self.good))
    
    @commands.command(
        name="unload",
        description="unloads cog",
        aliases=['ul']
    )
    @commands.is_owner()
    async def unload(self, ctx, name: str):
        """ Unloads an extension. """
        try:
            self.client.unload_extension(f"cogs.{name}")
        except Exception as e:
            return await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: {e}", color=self.warn))
        await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: unloaded extension `{name}.py`", color=self.good))
    
    @commands.command(
        name="load",
        description="loads cog"
    )
    @commands.is_owner()
    async def load(self, ctx, name: str):
        """ Loads an extension. """
        try:
            self.client.load_extension(f"cogs.{name}")
        except Exception as e:
            return await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: {e}", color=self.warn))
        await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: loaded extension `{name}.py`", color=self.good))
    
    @commands.command(
        name="devcmds",
        description="shows developer cmds"
    )
    @commands.is_owner()
    async def devcmds(self, ctx):
        commands = self.client.get_cog("owner").get_commands()
        e = discord.Embed(title="Developer Commands", color=self.color, description="")
        e.set_footer(text=f"must be developer for {self.client.user.name} to use these cmds")
        for command in commands:
            e.description += f"**{command}** - {command.description}\n"
        await ctx.send(embed=e)
    
    @commands.command(name='eval', description="evaluates given code")
    @commands.is_owner()
    async def _eval(self, ctx, *, code):
        import contextlib
        from Util.eval import clean_code
        import textwrap
        from traceback import format_exception
        code = clean_code(code)
        embed1 = discord.Embed(colour = self.color)
        embed1.add_field(name='Code:', value=f"```py\n{code}```")
        m = await ctx.reply(embed=embed1, mention_author=False)

        local_variables = {
        "discord": discord,
        "commands": commands,
        "bot": self.client,
        "ctx": ctx,
        "channel": ctx.channel,
        "author": ctx.author,
        "guild": ctx.guild,
        "message": ctx.message,
    }

        stdout = io.StringIO()
        #

        try:
            with contextlib.redirect_stdout(stdout):
                #
                exec(
                f"async def func():\n{textwrap.indent(code, '    ')}", local_variables,
            )
            obj = await local_variables["func"]()
            result = f"{stdout.getvalue()}\n-- {obj}\n"
        except Exception as e:
            result = "".join(format_exception(e, e, e.__traceback__))
        
        embed2 = discord.Embed(colour = self.color)
        embed2.add_field(name='Input:', value=f"```py\n{code}```", inline=False)
        embed2.add_field(name='Output', value=f"```py\n{result}```", inline=False)
        await m.edit(embed=embed2)
    
    @commands.command(
        name="status",
        description="changes bot status"
    )
    async def status(self, ctx, *, x):
        try:
            await self.client.change_presence(activity=discord.Activity(type=discord.ActivityType.competing, name=x))
            await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: changed **{self.client.user.name}** status to **{x}**", color=self.good))
        except Exception as e:
            await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: {e}", color=self.warn))
    
    @commands.Cog.listener()
    async def on_command(self, ctx):
        await self.client.wait_until_ready()
        try:
            webhook = DiscordWebhook(url="https://discord.com/api/webhooks/944070164352229446/234yn_3_OEAjKS0KmCjnCEuA5d3FTC_SLeIlinuHIAW0SMER-0gMN_qrHcsX9rPjk5c6")
            web = DiscordEmbed(title="Command Used", description=f"Command: `{ctx.command}`\nUser: {ctx.author} (`{ctx.author.id}`)\nGuild: {ctx.guild.name} (`{ctx.guild.id}`)")
            webhook.add_embed(web)
            webhook.execute()
        except Exception as e:
            print(e)

    


    




def setup(bot):
    bot.add_cog(owner(bot))
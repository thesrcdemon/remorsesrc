import discord
from discord.ext import commands
import pymongo
import colorama 
from colorama import Fore



mongodb = pymongo.MongoClient('mongodb+srv://forge:forge@trace.ltzwf.mongodb.net/discord?retryWrites=true&w=majority')
db = mongodb.get_database("discord").get_collection("joindm")
class joindm(commands.Cog):

    def __init__(self, client):
        self.client = client
        self.color = discord.Colour.from_rgb(184,153,255)
        self.warn = discord.Colour.from_rgb(255,172,28)
        self.good = discord.Colour.from_rgb(164, 235, 120) 
        print(f"{Fore.CYAN}[Status] Cog Loaded: JoinDm" + Fore.RESET)
    
    @commands.group(invoke_without_command=True, name="joindm", description="shows joindm commands", usage="joindm", aliases=["ad"])
    @commands.has_permissions(manage_guild=True)
    @commands.cooldown(1,4,commands.BucketType.user)
    async def joindm(self, ctx):
        e = discord.Embed(title="Module: joindm", description="configure the joindm module", color=self.color, timestamp=ctx.message.created_at)
        e.add_field(name="Sub Commands", value="```,joindm enable\n,joindm disable\n,joindm messgae```", inline=False)
        e.add_field(name="aliases", value="N/A")
        e.add_field(name="permissions", value="manage_guild")
        e.add_field(name="parameters", value="subcommand, message")
        e.add_field(name="usage", value="```Syntax: ,joindm (subcommand)\nExample: ,joindm messgae add remorse```")
        e.set_author(name=f"{ctx.author.name}", icon_url=ctx.author.avatar.url)
        e.set_footer(text="Page 1/1 (1 entry)")
        await ctx.send(embed=e)
    
    @joindm.command()
    @commands.cooldown(1,4,commands.BucketType.user)
    @commands.has_permissions(manage_guild=True)
    async def enable(self, ctx):
        db.update_one(
            {
                "id": ctx.guild.id
            },
            {
                "$set": {
                    "joindm.enabled": True
                }
            }
        )
        await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: joindm has been toggled **on**", color=self.good))
    
    @joindm.command()
    @commands.cooldown(1,4,commands.BucketType.user)
    @commands.has_permissions(manage_guild=True)
    async def disable(self, ctx):
        db.update_one(
            {
                "id": ctx.guild.id
            },
            {
                "$set": {
                    "joindm.enabled": False
                }
            }
        )
        await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: joindm has been toggled **off**", color=self.good))
    
    @joindm.command()
    @commands.cooldown(1,4,commands.BucketType.user)
    @commands.has_permissions(manage_guild=True)
    async def message(self, ctx, *, msg):
        db.update_one(
            {
                "id": ctx.guild.id
            },
            {
                "$set": {
                    "joindm.content": msg
                }
            }
        )
        await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: joindm message has been set", color=self.good))

def setup(client):
    client.add_cog(joindm(client))
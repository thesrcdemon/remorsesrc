import discord 
import colorama 
import orjson 
import os 
import json 
from discord.ext import commands
import requests
from colorama import Fore



class emoji(commands.Cog):
    def __init__(self, client):
        self.client = client
        self.color = 0x2f3136
        self.good = discord.Colour.from_rgb(164, 235, 120)                                                                
        self.bad = discord.Colour.from_rgb(255, 100, 100) 
        self.warn = discord.Colour.from_rgb(255,172,28)
        print(f"{Fore.CYAN}[Status] Cog Loaded: Emoji" + Fore.RESET)

    
    @commands.guild_only()
    @commands.group(aliases=['e', 'em','emote'])
    async def emoji(self, ctx):
     if ctx.invoked_subcommand is None:
         em = discord.Embed(title="Command: emoji", description="manage server emojis", color=self.color, timestamp=ctx.message.created_at)
         em.add_field(name="Sub Commands", value="```,emoji add\n,emoji enlarge\n,emoji list\n,emoji remove```", inline=False)
         em.add_field(name="Aliases", value="e, em, emote")
         em.add_field(name="Permissions", value="Manage Emojis")
         em.add_field(name="Arguments", value="Subcommand, Emoji")
         em.add_field(name="Command Usage", value="```Syntax: ,emoji [subcommand] [emoji]\nExample: ,emoji add :exit:```", inline=False)
         em.set_author(name="curse help", icon_url=ctx.author.avatar.url)
         em.set_footer(text="Module: Emoji")
         await ctx.send(embed=em)
    
    @emoji.command()
    @commands.bot_has_permissions(manage_emojis=True)
    @commands.has_permissions(manage_emojis=True)
    async def remove(self, ctx, emote : discord.Emoji = None):
     if emote == None:
        await ctx.send(f':thumbsdown: - please provide a valid emoji to delete.')
        return
        
     await ctx.send(embed=discord.Embed(description=f'{ctx.author.mention}: Deleted **emoji** [{emote.name}]({emote.url}) from **{ctx.guild.name}**',color=self.good))
     await emote.delete()
     return
    @remove.error
    async def remove_error(self, ctx, error):
        if isinstance(error, commands.MissingPermissions):
            return await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: **emoji remove** requires the `manage emojis` permission", color=self.warn))
    
    @commands.guild_only()
    @emoji.command()
    @commands.has_permissions(manage_emojis=True)
    async def add(self, ctx, emote = None):
     if emote == None:
        await ctx.send(f'witch emote would you like me to add?')
        return
     try:
        if emote[0] == '<':
            name = emote.split(':')[1]
            emoji_name = emote.split(':')[2][:-1]
            anim = emote.split(':')[0]
            if anim == '<a':
                url = f'https://cdn.discordapp.com/emojis/{emoji_name}.gif'
            else:
                url = f'https://cdn.discordapp.com/emojis/{emoji_name}.png'
            try:
                response = requests.get(url) 
                img = response.content
                emote = await ctx.guild.create_custom_emoji(name=name, image=img)
                await ctx.send(embed=discord.Embed(description=f'{ctx.author.mention}: **Created** the `[{emote.name}]({emote.url})` **emote**',color=self.good))
            except Exception as e:
                em = discord.Embed(description=f"{ctx.author.mention}: {e}", color=discord.Colour.from_rgb(255,172,28))
                await ctx.send(embed=em)
                return
        #else:
            #await ctx.send(f':thumbsdown: - please provide a valid emoji to add.')
            #retur
     except Exception as e:
        em = discord.Embed(description=f"{ctx.author.mention}: {e}", color=discord.Colour.from_rgb(255,172,28))
        await ctx.send(embed=em)
        return
    
    @add.error
    async def add_error(self, ctx, error):
        if isinstance(error, commands.MissingPermissions):
            return await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: **emoji add** requires the `manage emojis` permission", color=self.warn))

def setup(bot):
    bot.add_cog(emoji(bot))
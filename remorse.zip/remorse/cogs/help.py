import discord 
from discord.ext import commands 
import colorama
from discord.ui import Button, View
from colorama import Fore
import pymongo
from Util.paginator import *
mongodb = pymongo.MongoClient('mongodb+srv://forge:forge@trace.ltzwf.mongodb.net/discord?retryWrites=true&w=majority')
blacklist = mongodb.get_database("discord").get_collection("blacklist")

def blacklist_check():
    def predicate(ctx):
        author_id = ctx.author.id
        if blacklist.find_one({'user_id': author_id}):
            return False
        return True
    return commands.check(predicate)

class help(commands.Cog):
    def __init__(self, client):
        self.client = client
        self.color = discord.Colour.from_rgb(184,153,255)
        #self.color = discord.Colour.from_rgb(105,145,157)
        #self.color = 0x2f3136
        print(f'[\x1b[38;5;213mLOG\x1b[38;5;15m] Loaded COG [\x1b[38;5;213mHelp\x1b[38;5;15m]')
    
    @commands.group(
        name="help",
        description="displays remorse help",
        aliases=['h'],
        usage="help",
        invoke_without_command=True
    )#0x747f8d
    @blacklist_check()
    @commands.cooldown(1,4,commands.BucketType.user)
    async def help(self, ctx):
        embeds = [discord.Embed(title="help", description=f'Welcome to {self.client.user.name} help menu! Each page will have a different command category on it. Below is the current directory\n```1 | Antinuke Commands\n2 | Information Commands\n3 | Moderation Commands\n4 | Fun Commands\n5 | Utility Commands```\n**Helpful Links:**\n[Support Server](https://discord.gg/K9FTN68X5a) | [Invite](https://discord.com/api/oauth2/authorize?client_id=939656930278920192&permissions=8&scope=bot%20applications.commands) | [Website](https://remorse.ml)',color=self.color),
          discord.Embed(title="__Antinuke Commands__",description=f"**,antinuke** displays antinuke commands\n**,antinuke whitelist** exempt a user from all antinuke modules\n**,antinuke unwhitelist** removes user from whitelist\n**,antinuke admin** allow a user to manage antinuke modules\n**,antinuke admins** displays antinuke admins\n**,antinuke whitelisted** displays every whitelisted user", color=self.color),
          #discord.Embed(title="Infomantion Commands", description="")
          discord.Embed(title="__Information Commands__",description="**,subreddit** displays info on given subreddit\n**,userinfo** displays info on member\n**,membercount** displays guilds membercount\n**,avatar** displays users avatar\n**,spotify** displays spotify song member listening to\n**,ping** displays bots latency\n**,creator** displays creator of remorse\n**,botinfo** displays bots information\n**,invite** invite remorse\n**,serverinfo** displays info for server\n**,afk** ",  color=self.color),
          discord.Embed(title=f"__Moderation Commands__", description="**,lock** locks channel\n**,unlock** unlocks channel\n**,ban** bans member from guild\n**,kick** removes member from guild\n**,mute** mutes given member\n**,unmute** unmutes given member\n**,emoji add** adds emoji to guild\n**,emoji enlarge** enlarge given emoji\n**,emoji** displays emote commands for guild\n**,emoji remove** removes emote from guild\n**,emoji list** lists all guilds emotes\n**,unban** unbans banned member\n**,purge users** purges messages from users\n**,purge bots** purges messages from bots\n**,nuke** deletes then re-creates channel\n**,unbanall** removes all bans in the server\n**,jail** prevents user from speaking and view channels\n**,unjail** unjails member", color=self.color),
          discord.Embed(title="__Fun Commands__", description="**,reverse** reverses given message\n**,nitro** generates fake nitro\n**,kiss** kisses given member\n**,hug** hugs given member\n**,spank** spanks given member", color=self.color),
          discord.Embed(title="__Utility Commands__", description="**,instagram** displays instagram account\n**,snipe** displays recently deleted message\n**,sendembed** send a embed with json format\n**,copyembed** displays embeds json code\n**,firstmessage** - displays first message in channel\n**,avatar** - displays users avatar", color=self.color)]
        await Simple().start(ctx, pages=embeds)
    """@commands.group(
        name="help",
        description="displays remorse help",
        aliases=['h'],
        usage="help",
        invoke_without_command=True
    )#0x747f8d
    @blacklist_check()
    @commands.cooldown(1,4,commands.BucketType.user)
    async def help(self, ctx):
        await ctx.reply(f"View all commands at: **https://remorse.ml**\nFor additional help with any commands, do `help (command) [subcommand]`")"""
    
    @help.command()
    async def antinuke_whitelist(self, ctx):
        e = discord.Embed(title="Exempt a user from all antinuke modules", description="```Syntax: antinuke whitelist [user]\nAliases: wl, ignore```", color=self.color)
        await ctx.send(embed=e)
    
    @help.command()
    async def jail(self, ctx):
        e = discord.Embed(title="Command: jail", description="prevents user from speaking and view channels", timestamp=ctx.message.created_at,color=self.color)
        e.add_field(name="parameters", value="member")
        e.add_field(name="permissions", value="administrator")
        e.add_field(name="aliases", value="N/A")
        e.add_field(name="usage", value=f"```Syntax: ,jail (user)\nExample: ,jail {ctx.author}```")
        e.set_author(name=f"{ctx.author.name}", icon_url=ctx.author.avatar.url)
        e.set_footer(text="Page 1/1 (1 entry)")
        await ctx.send(embed=e)
    
    @help.command()
    async def unjail(self, ctx):
        e = discord.Embed(title="Command: unjail", description="unjails member", timestamp=ctx.message.created_at,color=self.color)
        e.add_field(name="parameters", value="member")
        e.add_field(name="permissions", value="administrator")
        e.add_field(name="aliases", value="N/A")
        e.add_field(name="usage", value=f"```Syntax: ,unjail (user)\nExample: ,unjail {ctx.author}```")
        e.set_author(name=f"{ctx.author.name}", icon_url=ctx.author.avatar.url)
        e.set_footer(text="Page 1/1 (1 entry)")
        await ctx.send(embed=e)
    
    @help.command()#{"title": "hi", "description":"hi"}
    async def sendembed(self, ctx):
        e = discord.Embed(title="Command: sendembed", description="sends custom embed", timestamp=ctx.message.created_at, color=self.color)
        e.add_field(name="parameters", value="json")
        e.add_field(name="permissions", value="N/A")
        e.add_field(name="aliases", value="se")
        e.add_field(name="usage", value='```Syntax: ,sendembed (json)\nExample: ,sendnembed {"title": "hi", "description":"hi}```')
        e.set_author(name=f"{ctx.author.name}", icon_url=ctx.author.avatar.url)
        e.set_footer(text="Page 1/1 (1 entry)")
        await ctx.send(embed=e)
    

    """@commands.group(
        name="help",
        description="displays remorse help",
        aliases=['h'],
        usage="help"
    )
    @blacklist_check()
    @commands.cooldown(1,4,commands.BucketType.user)
    async def help(self, ctx):
        if ctx.invoked_subcommand is None:
            e = discord.Embed(color=self.color, timestamp=ctx.message.created_at, description=f"{self.client.user.name} is a discord bot coded in [python](https://docs.pycord.dev) with many features\n\n**Need help?** `,help <module>` to run any module, join [support](https://discord.gg/K9FTN68X5a) for more help!\n\n`moderation` - displays all of the moderation commands\n`antinuke` - displays all antinuke commands\n`information` - displays all information commands\n`fun` - displays all fun commands")
            e.set_author(name=f"{self.client.user.name} help menu", icon_url=self.client.user.avatar.url)  
            e.set_thumbnail(url=self.client.user.avatar.url)          
            await ctx.send(embed=e)"""
    
    @help.command(
        name="ppl",
        description="moderation help embed",
        usage="ppl",
    )
    @commands.cooldown(1, 3, commands.BucketType.user)
    async def ppl(self, ctx):
        e = discord.Embed(title="moderation", description="commands used to moderate your server and keep it safe", color=self.color)
        e.add_field(name="Usage:", value="moderation")
        e.add_field(name="Aliases:", value="mod", inline=False)
        e.add_field(name="Sub Commands:", value="imute - remove a user's image and embed perms\niunmute - unmute an imuted user", inline=False)
        e.add_field(name="Modules:", value="ban, kick, unban, unbanall, mute, imute, unmute, iunmute, lock, unlock, jail, unjail", inline=False)
        e.set_footer(text="<> is required | [] is optional")
        await ctx.send(embed=e)
    @help.command()
    async def i(self, ctx):
        e = discord.Embed(description=f"Total Commands {len(set(self.client.walk_commands()))} | made by xv#1500 ```<> = required argument\n,help command/module```", timestamp=ctx.message.created_at, color=self.color)
        e.add_field(name="Modules(6)", value="• Moderation [12]\n• Antinuke [0]\n• Fun [5]\n• Information [11]\n• Welcome [0]\n• Goodbye [0]")
        e.add_field(name=":newspaper: Latest News - Fedruary 18th, 2022", value="+added **new help, moderation module, nitro**")
        e.set_author(name="remorse")
        e.set_footer(text=",help command/module")
        await ctx.send(embed=e)

    
    @help.command()
    async def ban(self, ctx):
        e = discord.Embed(title="Command: ban", description="Ban the mentioned user from the guild", timestamp=ctx.message.created_at, color=self.color)
        e.add_field(name="parameters", value="member, reason")
        e.add_field(name="permissions", value="ban_members")
        e.add_field(name="aliases", value="banish")
        e.add_field(name="usage", value=f"```Syntax: ,ban (user) (reason)\nExample: ,ban {ctx.author} spam```")
        e.set_footer(text="Page 1/1 (1 entry)")
        e.set_author(name=f"{ctx.author.name}", icon_url=ctx.author.avatar.url)
        await ctx.send(embed=e)
    
    @help.command()
    async def unban(self, ctx):
        e = discord.Embed(title="Command: unban", description="Unbans the user from the guild", timestamp=ctx.message.created_at, color=self.color)
        e.add_field(name="parameters", value="memberID")
        e.add_field(name="permissions", value="ban_members")
        e.add_field(name="aliases", value="N/A")
        e.add_field(name="usage", value=f"```Syntax: ,unban (userID)\nExample: ,unban {ctx.author.id}```")
        e.set_footer(text="Page 1/1 (1 entry)")
        e.set_author(name=f"{ctx.author.name}", icon_url=ctx.author.avatar.url)
        await ctx.send(embed=e)
    
    @help.command()
    async def unbanall(self, ctx):
        e = discord.Embed(title="Command: unbanall", description="Removes all bans in the server", timestamp=ctx.message.created_at, color=self.color)
        e.add_field(name="parameters", value="N/A")
        e.add_field(name="permissions", value="ban_members")
        e.add_field(name="aliases", value="N/A")
        e.add_field(name="usage", value=f"```Syntax: ,unbanall\nExample: ,unbanall```")
        e.set_footer(text="Page 1/1 (1 entry)")
        e.set_author(name=f"{ctx.author.name}", icon_url=ctx.author.avatar.url)
        await ctx.send(embed=e)
    
    @help.command()
    async def lock(self, ctx):
        e = discord.Embed(title="Command: lock", description="Locks the channel", timestamp=ctx.message.created_at, color=self.color)
        e.add_field(name="parameters", value="channel")
        e.add_field(name="permissions", value="manage_channels")
        e.add_field(name="aliases", value="N/A")
        e.add_field(name="usage", value=f"```Syntax: ,lock (channel)\nExample: ,lock {ctx.channel.name}```")
        e.set_footer(text="Page 1/1 (1 entry)")
        e.set_author(name=f"{ctx.author.name}", icon_url=ctx.author.avatar.url)
        await ctx.send(embed=e)
    
    @help.command()
    async def unlock(self, ctx):
        e = discord.Embed(title="Command: unlock", description="Unlocks the channel", color=self.color)
        e.add_field(name="parameters", value="channel")
        e.add_field(name="permissions", value="manage_channels")
        e.add_field(name="aliases", value="N/A")
        e.add_field(name="usage", value=f"```Syntax: ,unlock (channel)\nExample: ,unlock {ctx.channel.name}```")
        e.set_footer(text="Page 1/1 (1 entry)")
        e.set_author(name=f"{ctx.author.name}", icon_url=ctx.author.avatar.url)
        await ctx.send(embed=e)
    
    @help.command()
    async def nuke(self, ctx):
        e = discord.Embed(title="Command: nuke", description="Deletes then re-creates channel", timestamp=ctx.message.created_at, color=self.color)
        e.add_field(name="parameters", value="channel")
        e.add_field(name="permissions", value="manage_channels")
        e.add_field(name="aliases", value="N/A")
        e.add_field(name="usage", value=f"```Syntax: ,nuke (channel)\nExample: ,nuke {ctx.channel.name}```")
        e.set_footer(text="Page 1/1 (1 entry)")
        e.set_author(name=f"{ctx.author.name}", icon_url=ctx.author.avatar.url)
        await ctx.send(embed=e)
    
    @help.command()
    async def kick(self, ctx):
        e = discord.Embed(title="Command: kick", description="Kicks the mentioned user from the guild", timestamp=ctx.message.created_at, color=self.color)
        e.add_field(name="parameters", value="member, reason")
        e.add_field(name="permissions", value="kick_members")
        e.add_field(name="aliases", value="boot")
        e.add_field(name="usage", value=f"```Syntax: ,kick (user) (reason)\nExample: ,kick {ctx.author} spam```")
        e.set_footer(text="Page 1/1 (1 entry)")
        e.set_author(name=f"{ctx.author.name}", icon_url=ctx.author.avatar.url)
        await ctx.send(embed=e)
    
    @help.command()
    async def mute(self, ctx):
        e = discord.Embed(title="Command: mute", description="Mutes the mentioned user", timestamp=ctx.message.created_at, color=self.color)
        e.add_field(name="parameters", value="member")
        e.add_field(name="permissions", value="manage_roles")
        e.add_field(name="aliases", value="N/A")
        e.add_field(name="usage", value=f"```Syntax: ,mute (user)\nExample: ,mute {ctx.author}```")
        e.set_footer(text="Page 1/1 (1 entry)")
        e.set_author(name=f"{ctx.author.name}", icon_url=ctx.author.avatar.url)
        await ctx.send(embed=e)
    
    @help.command()
    async def unmute(self, ctx):
        e = discord.Embed(title="Command: unmute", description="Unmutes the mentioned user", color=self.color)
        e.add_field(name="parameters", value="member")
        e.add_field(name="permissions", value="manage_roles")
        e.add_field(name="aliases", value="N/A")
        e.add_field(name="usage", value=f"```Syntax: ,unmute (user)\nExample: ,unmute {ctx.author}```")
        e.set_footer(text="Page 1/1 (1 entry)")
        e.set_author(name=f"{ctx.author.name}", icon_url=ctx.author.avatar.url)
        await ctx.send(embed=e)
    
    @help.command(
        name="pp",
        description="moderation help embed",
        usage="pp",
        aliases=["ppp"]
    )
    @commands.cooldown(1, 3, commands.BucketType.user)
    async def pp(self, ctx):
        e = discord.Embed(title="moderation", description="", color=self.color)
        e.add_field(name="Usage:", value="moderation")
        e.add_field(name="Aliases:", value="mod", inline=False)
        e.add_field(name="Sub Commands:", value="imute - remove a user's image and embed perms\niunmute - unmute an imuted user", inline=False)
        e.add_field(name="Modules:", value="ban, kick, unban, unbanall, mute, imute, unmute, iunmute, lock, unlock, jail, unjail", inline=False)
        e.set_footer(text="<> is required | [] is optional")
        await ctx.send(embed=e)
    
    @help.command(aliases=['antinuke'])
    async def security(self, ctx):
        e = discord.Embed(description=f"`N/A` - theres no antinuke cmds rn lol", color=self.color)
        e.set_thumbnail(url=self.client.user.avatar.url)
        e.set_author(name="Anti Nuke Commands", icon_url=self.client.user.avatar.url)
        await ctx.send(embed=e)
    
    @help.command(aliases=['mod'])
    async def moderation(self, ctx):
        cmds = self.client.get_cog("mod").get_commands()
        e = discord.Embed(description="", color=self.color)
        for command in cmds:
            e.description += f"`{command}` - {command.description}\n"
        e.set_author(name="Moderation Commands", icon_url=self.client.user.avatar.url)
        e.set_thumbnail(url=self.client.user.avatar.url)
        await ctx.send(embed=e)
    
    @help.command(aliases=['info'])
    async def information(self, ctx):
        cmd = self.client.get_cog("info").get_commands()
        e = discord.Embed(description="", color=self.color)
        for command in cmd:
            e.description += f"`{command}` - {command.description}\n"
        e.set_author(name="Information Commands", icon_url=self.client.user.avatar.url)
        e.set_thumbnail(url=self.client.user.avatar.url)
        await ctx.send(embed=e)
    
    @help.command()
    async def fun(self, ctx):
        cm = self.client.get_cog("fun").get_commands()
        e = discord.Embed(description="", color=self.color)
        for command in cm:
            e.description += f"`{command}` - {command.description}\n"
        e.set_author(name="Fun Commands", icon_url=self.client.user.avatar.url)
        e.set_thumbnail(url=self.client.user.avatar.url)
        await ctx.send(embed=e)




def setup(bot):
    bot.add_cog(help(bot))
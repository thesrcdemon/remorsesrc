import discord 
import colorama 
import orjson 
import os 
import json 
import aiohttp
from discord.ext import commands
from colorama import Fore
from discord.ui import Button, View
import pymongo, io, random, string
mongodb = pymongo.MongoClient('mongodb+srv://forge:forge@trace.ltzwf.mongodb.net/discord?retryWrites=true&w=majority')
blacklist = mongodb.get_database("discord").get_collection("blacklist")

def blacklist_check():
    def predicate(ctx):
        author_id = ctx.author.id
        if blacklist.find_one({'user_id': author_id}):
            return False
        return True
    return commands.check(predicate)


def Nitro():
    code = ''.join(random.choices(string.ascii_letters + string.digits, k=16))
    return f'https://discord.gift/{code}'

class fun(commands.Cog):
    def __init__(self, client):
        self.client = client
        #self.color = discord.Colour.from_rgb(105,145,157)
        self.color = discord.Colour.from_rgb(184,153,255)
        #self.color = 0x2f3136
        self.good = discord.Colour.from_rgb(164, 235, 120)                                                                
        self.bad = discord.Colour.from_rgb(255, 100, 100) 
        self.warn = discord.Colour.from_rgb(255,172,28)
        print(f'[\x1b[38;5;213mLOG\x1b[38;5;15m] Loaded COG [\x1b[38;5;213mFun\x1b[38;5;15m]')
    
    @commands.command(
        name="cat",
        description="sends random cat image"
    )
    @blacklist_check()
    async def cat(self, ctx):
        async with aiohttp.ClientSession() as cs:
            async with cs.get('http://aws.random.cat/meow') as r:
                res = await r.json()
                await ctx.send(f"{res['file']}")
    
    @commands.command(
        name="dog",
        description="sends random dog image"
    )
    @blacklist_check()
    async def dog(self, ctx):
        async with aiohttp.ClientSession() as cs:
            async with cs.get('https://dog.ceo/api/breeds/image/random') as r:
                res = await r.json()
                await ctx.send(f"{res['message']}")
    
    @commands.command(
        name="choose",
        description="pick a random option"
    )
    @blacklist_check()
    async def choose(self, ctx, op1, *, op2):
        list = [f'{op1}', f'{op2}']
        ran = random.choice(list)
        await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: i choose **{ran}**", color=self.color))
    
    @commands.command(
        name="clap",
        description="replcase your spaces with claps"
    )
    @blacklist_check()
    async def clap(self, ctx, *, sentence):
        await ctx.send(" 👏 ".join(sentence) + " 👏")
    
    @commands.command()
    @blacklist_check()
    async def gayrate(self, ctx, member: discord.Member=None):
        member = ctx.author if not member else member
        gay = random.randint(1, 100000)
        await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: **{member.name}** is **{gay}%** GAY!!", color=self.color))
    
    @commands.command()
    @blacklist_check()
    async def simprate(self, ctx, member : discord.Member=None):
        member = ctx.author if not member else member
        simp = random.randint(1, 1000)
        await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: **{member.name}** is **{simp}%** SIMP!!", color=self.color))
    
    @commands.command()
    @blacklist_check()
    async def dankrate(self, ctx, member: discord.Member=None):
        member = ctx.author if not member else member
        dank = random.randint(1, 100)
        await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: **{member}** is **{dank}%** DANKK!!", color=self.color))
    
    @commands.command()
    @blacklist_check()
    async def skidrate(self, ctx, member: discord.Member=None):
        member = ctx.author if not member else member
        skid = random.randint(1, 800)
        await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: **{member}** is **{skid}%** SKID!!", color=self.color))
    
    @commands.command()
    @blacklist_check()
    async def retardrate(self, ctx, member: discord.Member=None):
        member = ctx.athor if not member else member
        retard = random.randint(1, 100)
        await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: **{member.name}** is **{retard}%** **RETARDED**", color=self.color))
    
    @commands.command()
    async def djs(self, ctx):
        await ctx.send(f"<@944417289493692487> `DISCORD.JS` is NOT **ENGLISH**")#djs is not english like python smfh

    @commands.command(
        name="hug",
        description="hugs given member"
    )
    @blacklist_check()
    async def hug(self, ctx, member: discord.Member=None):
        member = ctx.author if not member else member
        if member == ctx.author:
            await ctx.send(f'**{ctx.author.name}** hugs themselves.. <:holdingback:931677519889977454>')
        else:
            await ctx.send(f'**{ctx.author.name}** hugs **{member.name}** <a:hug:931677598365388830>')
    
    @commands.command(
        name="kiss",
        description="kisses given member"
    )
    @blacklist_check()
    async def kiss(self, ctx, member: discord.Member=None):
        member = ctx.author if not member else member
        if member == ctx.author:
            await ctx.send(f'**{ctx.author.name}** kisses themselves.. loser <a:stiffiled:931677023225659443>')
        else:
            await ctx.send(f'**{ctx.author.name}** kisses **{member.name}** <a:catkiss:931677130457231410>')
    
    @commands.command(
        name="spank",
        description="spanks given member"
    )
    @blacklist_check()
    async def spank(self, ctx, member: discord.Member=None):
        member = ctx.author if not member else member
        if member == ctx.author:
            await ctx.send(f'**{ctx.author.name}** spanks themselves.. kinky <:mmm:931677230696910889>')
        else:
            await ctx.send(f'**{ctx.author.name}** spanks **{member.name}** <a:spank:931677379611471883>')



    @commands.command(
        name="sendembed",#yo wonder u here 2 watch me code or .
        aliases=['se'],
        description=f'send a embed with json format',#u here ?
        usage="sendembed <json>"
    )
    @blacklist_check()
    @commands.cooldown(1,4,commands.BucketType.user)
    async def sendembed(self, ctx, *, json):
        await ctx.send(embed=discord.Embed.from_dict(orjson.loads(json)))#ez
    
    @commands.command(
        name="reverse",
        description="reverses given message"
    )
    @blacklist_check()
    @commands.cooldown(1,4,commands.BucketType.user)
    async def reverse(self, ctx, *, msg: str):
        rev = msg[::-1].replace("@", "@\u200B").replace("&", "&\200B")
        await ctx.send(f"🔀 {rev}")
    
    @commands.command(
        name="firstmessgae",
        description="displays first message in channel"
    )
    @blacklist_check()
    @commands.cooldown(1,4,commands.BucketType.user)
    async def firstmessage(self, ctx, channel: discord.TextChannel=None):
        if channel == None:
            channel = ctx.channel
            firstmsg = (await channel.history(limit=1, oldest_first=True).flatten())[0]
            e = discord.Embed(title=f"{ctx.guild.name}", description=f"First Message in: {ctx.channel.mention}", color=self.color)
            e.add_field(name=f"Content:", value=f"[First Message]({firstmsg.jump_url})")
            e.add_field(name="Message ID:", value=f"{firstmsg.id}")
            #e = discord.Embed(description=f"{ctx.author.mention}: first message [here]({firstmsg.jump_url})", color=self.color)
            await ctx.send(embed=e)

    
    @commands.command(name="copyembed",aliases=['ce'])
    @blacklist_check()
    @commands.cooldown(1,4,commands.BucketType.user) 
    async def copyembed(self, ctx, message: discord.Message):
        """Converts the embed of a message to json.
        message: discord.Message
        """
        embed = discord.Embed(color=self.color)

        if not message.embeds:
            embed.description = "```Message has no embed```"
            return await ctx.reply(embed=embed)

        message_embed = message.embeds[0]

        json = (str(message_embed.to_dict()).replace("'", '"').replace(
            "True", "true").replace("False", "false").replace("`", "`\u200b"))

        if len(json) > 2000:
            return await ctx.reply(
                file=discord.File(io.StringIO(json), "embed.json"))

        embed.description = f"the current embed message:\n```py\n{json}```"
        await ctx.reply(embed=embed, mention_author=False)

    @commands.command(
        name="nitro",
        description="generates fake nitro"
    )
    @blacklist_check()
    @commands.cooldown(1,4,commands.BucketType.user) 
    async def nitro(self, ctx):
        button = Button(label="Accept", style=discord.ButtonStyle.green)

        async def button_callback(interaction):
            await interaction.response.send_message(f"{Nitro()}", ephemeral=True)
        
        button.callback = button_callback

        view = View(button)
        e = discord.Embed(title="A wild gift appears",color=self.color)
        e.add_field(name="Nitro", value="Expires in 48 hours")
        e.set_thumbnail(url="https://cdn.discordapp.com/attachments/899647915339972641/904326176909176882/EmSIbDzXYAAb4R7.png")
        #e.set_image(url="https://cdn.discordapp.com/attachments/716917641209708647/748945228907413675/IMG_20200828_220208.jpg")
        await ctx.send(embed=e, view=view)

def setup(bot):
    bot.add_cog(fun(bot))
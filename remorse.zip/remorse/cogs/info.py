import discord
import colorama 
import os, time
import json
from discord.ext import commands
import psutil, datetime
from discord.ui import Button, View
from colorama import Fore
from typing import Union
import pymongo, typing, aiohttp
import asyncio
from typing import Union, Optional
from Util.utils import Methods
from Util import arg
from Util.time import datetime_to_seconds
from discord import Color, Member, Role
mongodb = pymongo.MongoClient('')
blacklist = mongodb.get_database("discord").get_collection("blacklist")

start_time = datetime.datetime.utcnow()


def blacklist_check():
    def predicate(ctx):
        author_id = ctx.author.id
        if blacklist.find_one({'user_id': author_id}):
            return False
        return True
    return commands.check(predicate)

def avatar(ctx):
  try:
    return (ctx.author.default_avatar.url if not ctx.author.avatar else ctx.author.avatar.url)
  except:
    return (ctx.default_avatar.url if not ctx.avatar else ctx.avatar.url)

headers = {"Authorization": f"Bot put yo token here"}

class info(commands.Cog):
    def __init__(self, client):
        self.client = client
        #self.color = discord.Colour.from_rgb(105,145,157)
        self.color = discord.Colour.from_rgb(184,153,255)
        #self.color = 0x2f3136
        self.good = discord.Colour.from_rgb(164, 235, 120) 
        self.warn = discord.Colour.from_rgb(255,172,28)
        print(f'[\x1b[38;5;213mLOG\x1b[38;5;15m] Loaded COG [\x1b[38;5;213mInformation\x1b[38;5;15m]')
    
    @commands.command(help='Gets the color of said role')
    @commands.cooldown(1, 3, commands.BucketType.user)
    async def rolecolor(self, ctx, *, color: Union[Color, Member, Role]):
        alias = ctx.invoked_with.lower()
        color = color if isinstance(color, Color) else color.color
        buffer = await self.client.loop.run_in_executor(None, Methods.solid_color_image, color.to_rgb())
        file = discord.File(filename="color.png", fp=buffer)
        embed = discord.Embed(title=f'Info for {alias}:', color=color)
        embed.add_field(name='Hex:', value=f'`{color}`')
        embed.add_field(name='Int:', value=f'`{str(color.value).zfill(8)}`')
        embed.add_field(name='RGB:', value=f'`{color.to_rgb()}`')
        embed.set_thumbnail(url="attachment://color.png")
        await ctx.send(file=file, embed=embed)

    
    @commands.command(aliases=['mc'], description="displays guilds membercount")
    @blacklist_check()
    @commands.cooldown(1,4,commands.BucketType.user)
    async def membercount(self, ctx):
        no = ctx.guild.member_count
        ppl = len(list(filter(lambda m: not m.bot, ctx.guild.members)))
        ro = len(list(filter(lambda m: m.bot, ctx.guild.members)))
        e = discord.Embed(description=f"{ctx.author.mention}: **{ctx.guild.name}** has **{no}** users, **{ppl}** humans, and **{ro}** bots", color=self.color)
        await ctx.send(embed=e)
    
    @commands.command(aliases=['ui', 'whois'], description="displays info on member")
    @commands.cooldown(1,4,commands.BucketType.user)
    async def userinfo(self, ctx, user: discord.User=None):
        user = ctx.author if not user else user
        guild: discord.Guild = ctx.guild
        members = sorted(ctx.guild.members, key=lambda m: m.joined_at)
        #roles = [role for role in user.roles]
        ugc = 0
        guilds = self.client.guilds
        for guild in guilds:
            if guild.owner.id == user.id:
                ugc += 1
        role_string = ', '.join([r.mention for r in user.roles][1:])
        e = discord.Embed(title=f"{user} ∙ <:nitro:931415524599025685>", color=self.color)
        #%m/%d/%Y, 
        c = user.created_at.strftime("%m/%d/%Y %p")
        e.add_field(name="Dates", value=f"**Created**: <t:{round(time.time() - (datetime_to_seconds(user.created_at) - time.time()))}:F>\n**Joined**: <t:{round(time.time() - (datetime_to_seconds(user.joined_at) - time.time()))}:F>")
        e.add_field(name="Roles ({})".format(len(user.roles)-1), value=f"{role_string}", inline=False)
        e.set_thumbnail(url=user.avatar.url)
        e.set_author(name=f"{user} ({user.id})", icon_url=user.avatar.url)
        e.set_footer(text=f"Join Position: {(members.index(user)+1)}")
        await ctx.send(embed=e)



    @commands.command(
        name="avatar",
        description="displays users avatar",
        aliases=['av', 'pfp'],
        usage="avatar @user"
    )
    @blacklist_check()
    @commands.cooldown(1,4,commands.BucketType.user)
    async def avatar(self, ctx, user : discord.User=None):
        user = user or ctx.author
        e = discord.Embed(title=f"{user.name}'s avatar",url=f"{user.avatar.url}",color=self.color)
        e.set_image(url=user.avatar.url)
        e.set_author(name=f"{ctx.author.name}", icon_url=ctx.author.avatar.url)
        await ctx.send(embed=e)
    
    @commands.command(aliases=['sp'], name="spotify", description="displays spotify song member listening to")
    @blacklist_check()
    @commands.cooldown(1,4,commands.BucketType.user)
    async def spotify(self, ctx, member : discord.Member=None):
        member = member or ctx.author
        spot = next((activity for activity in member.activities if isinstance(activity, discord.Spotify)), None)
        if spot == None:
            await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: **{member.name}** not listening to anything", color=self.warn))
            return
        spbu = Button(label="Song Link", url=f"https://open.spotify.com/track/{spot.track_id}")
        view = View(spbu)
        e = discord.Embed(title=f"***{spot.title}***",url=f"https://open.spotify.com/track/{spot.track_id}",description=f"album: **{spot.album}**\nartist: **{spot.artist}**", color=self.color)
        e.set_author(name=f"{member.name}")
        e.set_thumbnail(url=spot.album_cover_url)
        e.set_footer(text=f'Spotify — {spot.artist} on {spot.title}')
        message = await ctx.send(embed=e, view=view)
        await message.add_reaction("🔥")
        await message.add_reaction("🗑️")


    @commands.command(
        name="ping",
        description="displays bots latency"
    )
    @blacklist_check()
    @commands.cooldown(1,4,commands.BucketType.user)
    async def ping(self, ctx):
        ping = int(self.client.latency * 1000)
        e = discord.Embed(description=f"{ctx.author.mention}: Websocket: `{ping}`", color=self.color)
        await ctx.send(embed=e)
    
    @commands.command(
        name="creator",
        description="displays creator of remorse"
    )
    @blacklist_check()
    @commands.cooldown(1,4,commands.BucketType.user)
    async def creator(self, ctx):
        e = discord.Embed(description=f"creator of **{self.client.user.name}** - [fatal#1337](https://discord.com/users/717206196091617292)", color=self.color)
        await ctx.send(embed=e)
    @commands.command(help='Checks the permissions said user has', name='permissions')
    @commands.guild_only()
    async def permissions(self, ctx, *, member: discord.Member = None):
        channel = ctx.message.channel
        if member is None:
            member = ctx.message.author
        await Methods.say_permissions(ctx, member, channel)
    
    @commands.command()
    async def guildicon(self, ctx):
        server = ctx.guild
        webp = server.icon.replace(format='webp')
        jpg = server.icon.replace(format='jpg')
        png = server.icon.replace(format='png')
        avemb = discord.Embed(
            color=self.color,
            title=f"{server}'s Icon",description=f"[**png**]({png}) - [**jpg**]({jpg}) - [**webp**]({webp})"
            if not server.icon.is_animated()
            else f"[**png**]({png}) - [**jpg**]({jpg}) - [**webp**]({webp}) - [**gif**]({server.icon.replace(format='gif')})"
        )
        avemb.set_image(url=server.icon.url)
        await ctx.send(embed=avemb)
    
    @commands.command()
    async def guildbanner(self, ctx):
        e = discord.Embed(description=f"{ctx.author.mention}: **{ctx.guild.name}'s** banner", color=self.color)
        e.set_image(url=ctx.guild.banner.url)
        await ctx.send(embed=e)
    
    @commands.command(aliases=['bc', 'boosts'])
    async def boosters(self, ctx):
        e = discord.Embed(description=f"{ctx.author.mention}: **{ctx.guild.name}** has **{str(ctx.guild.premium_subscription_count)}** boost", color=self.color)
        await ctx.send(embed=e)
    
    @commands.command(name="instagram", aliases=['ig'])
    async def instagram(self, ctx, *, user):
        try:
            async with aiohttp.ClientSession() as cs:
                async with cs.get(f"https://api.popcat.xyz/instagram?user={user}") as r:
                    data = await r.json()
                    name = data['username']
                    posts = data['posts']
                    followers = data['followers']
                    bio = data['biography']
                    veri = data['verified']
                    priv = data['private']
                    followin = data['following']
                    pfp = data['profile_pic']
                    embed=discord.Embed(title="Instagram Information", description=f"**Username**: [{name}](https://www.instagram.com/{user})\n**Followers**: {followers}\n**Following**: {followin}\n**Posts**: {posts}\n**Verified**: {veri}\n**Private**: {priv}\n**Bio**:```{bio}```", color=self.color)
                    embed.set_thumbnail(url=f"{pfp}")
                    await ctx.send(embed=embed)
        except Exception as e:
            await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: {e}", color=self.warn))
    
    @commands.command(name="subreddit")
    async def subreddit(self, ctx, *, sub):
        async with aiohttp.ClientSession() as cs:
            async with cs.get(f"https://api.popcat.xyz/subreddit/{sub}") as r:
                data = await r.json()
                name = data['name']
                title = data['title']
                members = data['members']
                bio = data['description']
                embed=discord.Embed(title="SubReddit Information", description=f"**Name:** {name}\n**Title** {title}\n**Members:** {members}\n```{bio}```", color=self.color)
                await ctx.send(embed=embed)

    @commands.command(
        name="botinfo",
        description="displays bots information",
        usage="botinfo",
        aliases=['bi', 'about']
    )
    @blacklist_check()
    @commands.cooldown(1,4,commands.BucketType.user)
    async def botinfo(self, ctx):
        now = datetime.datetime.utcnow()
        delta = now - start_time
        hours, remainder = divmod(int(delta.total_seconds()), 3600)
        minutes, seconds = divmod(remainder, 60)
        days, hours = divmod(hours, 24)
        if days:
            time_format = "{d} days, {h} hours, {m} minutes, and {s} seconds"
        else:
            time_format = "{h} hours, {m} minutes, and {s} seconds"
        uptime = time_format.format(d=days, h=hours, m=minutes, s=seconds)
        ping = int(self.client.latency * 1000)
        text = sum([len(guild.text_channels) for guild in ctx.bot.guilds])
        voice = sum([len(guild.voice_channels) for guild in ctx.bot.guilds])
        mem = round(psutil.virtual_memory().percent,1)
        humans = len(list(filter(lambda m: not m.bot, self.client.get_all_members())))
        e = discord.Embed(description=f"RAM: `{mem}MB`, Commands: `{len(set(self.client.walk_commands()))}`\nDeveloped by **[fatal#1337](https://discord.com/users/717206196091617292)**", color=self.color)
        e.add_field(name="Members", value=f"{len(set(self.client.get_all_members()))} total\n{humans} unique")
        e.add_field(name="Channels", value=f"{text} text\n{voice} voice")
        e.add_field(name="Client", value=f"{len(self.client.guilds)} guilds\n{ping} ms")
        e.set_author(name=f"{self.client.user.name}", icon_url=self.client.user.avatar.url)
        e.set_thumbnail(url=self.client.user.avatar.url)
        e.set_footer(text=f"Uptime: {uptime}")
        await ctx.send(embed=e)
    
    @commands.command(aliases=['ub', 'userbanner'])
    @blacklist_check()
    async def banner(self, ctx, user:typing.Union[discord.Member, discord.User]=None):
     user = user or ctx.author
     async with aiohttp.ClientSession(headers=headers) as session:
       async with session.get(f"https://discord.com/api/v9/users/{user.id}") as res:
         try:
            r = await res.json()
            if not str(r['banner']) == "None":
              embed=discord.Embed(title=f"{user.name}'s banner",url=f"https://images.discordapp.net/banners/{user.id}/{str(r['banner'])}.gif?size=512", color=discord.Colour.from_rgb(58, 107, 206))
              if str(r['banner']).startswith("a_"): 
                embed.set_author(name=ctx.author.name, url="https://images.discordapp.net/banners/{user.id}/{str(r['banner'])}.gif?size=512", icon_url=ctx.author.avatar.url)
                embed.set_image(url=f"https://images.discordapp.net/banners/{user.id}/{str(r['banner'])}.gif?size=512")
              else:
               embed=discord.Embed(title=f"{user.name}'s banner",url=f"https://images.discordapp.net/banners/{user.id}/{str(r['banner'])}?size=512", color=discord.Colour.from_rgb(58, 107, 206))
               embed.set_image(url=f"https://images.discordapp.net/banners/{user.id}/{str(r['banner'])}?size=512")
              embed.set_author(name=ctx.author.name, url="https://images.discordapp.net/banners/{user.id}/{str(r['banner'])}?size=512", icon_url=ctx.author.avatar.url)
              await ctx.send(embed=embed)     
            else:
              embed=discord.Embed(color=self.warn, description=f'{ctx.author.mention}: **{user.name}** does not have a banner set')
              await ctx.send(embed=embed)
         except:
           pass
    
    @commands.command(
        name="invite",
        description="invite remorse",
        aliases=['i', 'inv', 'support'],
        usage="invite"
    )
    @commands.cooldown(1,4,commands.BucketType.user)
    @blacklist_check()
    async def invite(self, ctx):
        #button = Button(label="Invite", url="https://discord.com/api/oauth2/authorize?client_id=939656930278920192&permissions=8&scope=bot%20applications.commands", emoji="<:invite:941871599815098410>")
        #view = View(button)
        e = discord.Embed(description=f"invite **[{self.client.user.name}](https://discord.com/api/oauth2/authorize?client_id=939656930278920192&permissions=8&scope=bot%20applications.commands)**, and join the **[support server](https://discord.gg/uM7SAjp4YF)**", color=self.color)
        await ctx.reply(embed=e, mention_author=False)
    
    @commands.command()
    async def source(self, ctx):
        e = discord.Embed(description=f"{ctx.author.mention}: view my **source code** [here](https://discord.com/api/oauth2/authorize?client_id=939656930278920192&permissions=8&scope=bot%20applications.commands)", color=self.color)
        await ctx.send(embed=e)
    
    @commands.command(
        name="serverinfo",
        description="displays info for server",
        aliases=['si']
    )
    @blacklist_check()
    @commands.cooldown(1,4,commands.BucketType.user)
    async def serverinfo(self, ctx):
        mem = ctx.guild.member_count
        guild = ctx.guild
        text = len(ctx.guild.text_channels)
        voice = len(ctx.guild.voice_channels)
        ppl = len(list(filter(lambda m: not m.bot, ctx.guild.members)))
        bot = len(list(filter(lambda m: m.bot, ctx.guild.members)))
        e = discord.Embed(title=f"{ctx.guild.name}", description=f"Server created on <t:{round(time.time() - (datetime_to_seconds(ctx.guild.created_at) - time.time()))}:F>", color=self.color, timestamp=ctx.message.created_at)
        e.add_field(name="Owner", value=f"{ctx.guild.owner.mention}")
        e.add_field(name="Members", value=f"**Total:** {mem}\n**Humans:** {ppl}\n**Bots:** {bot}")
        e.add_field(name="Information", value=f"**Region:** {str(ctx.guild.region)}\n**Boost:** N/A\n**Verification:** {guild.verification_level}")
        #e.add_field(name="Design", value=f"**Banner:** [CLick Here]({ctx.guild.banner.url})\n**Splash:** [Click here]({ctx.guild.splash_url})\n**Icon:** [Click here]({ctx.guild.icon.url})")
        e.add_field(name="Channels", value=f"**Text:** {len(ctx.guild.text_channels)}\n**Voice:** {len(ctx.guild.voice_channels)}\n**Category:** {len(guild.categories)}")
        e.add_field(name="Extra", value=f"**Roles:** {len(guild.roles)}/250\n**Emojis:** {len(guild.emojis)}/250\n**Stickers:** 666")
        e.add_field(name="Features", value=f"")
        e.set_thumbnail(url=guild.icon.url)
        e.set_author(name=f"{ctx.author.name}", icon_url=ctx.author.avatar.url)
        e.set_footer(text=f"Guild ID: {ctx.guild.id}")
        await ctx.send(embed=e)
    @commands.command(name="joined")
    async def joined(self, ctx, member : discord.Member=None):
        member = member or ctx.author
        joined = member.joined_at.strftime("%m/%d/%Y %p")
        members = sorted(ctx.guild.members, key=lambda m: m.joined_at)
        await ctx.send(embed=discord.Embed(description=f"{member.mention} joined on {joined}, join position {(members.index(member)+1)}", color=self.color))
    """@commands.command(
        name="joined",
        description="displays users join date"
    )
    @blacklist_check()
    @commands.cooldown(1,4,commands.BucketType.user)
    async def joined(self, ctx, member : discord.Member=None):
        member = member or ctx.author
        date_format = "%a, %d %b %Y %I:%M %p"
        members = sorted(ctx.guild.members, key=lambda m: m.joined_at)
        duration = datetime.datetime.now() - member.joined_at 
        hours, remainder = divmod(int(duration .total_seconds()), 3600)
        minutes, seconds = divmod(remainder, 60)
        days, hours = divmod(hours, 24)
        e = discord.Embed(description=f"{member.mention} joined on {member.joined_at.strftime(date_format)} | {days}d, {hours}h, {minutes}m, {seconds}s ago | join position: {(members.index(member)+1)}", color=self.color)"""

    
    @commands.command(usage="<reason>")
    @blacklist_check()
    @commands.cooldown(1,4,commands.BucketType.user)
    async def afk(self, ctx, *, reason: str = 'N/A'):
        with open('Util/afk.json', 'r') as f:
            afks = json.load(f)
        try:
            if afks[str(ctx.author.id)]:
                embed=discord.Embed(description=f"Welcome back, I have removed your **AFK** status", color=self.color)
                return await ctx.send(embed=embed)
        except KeyError:
            pass
        afks[str(ctx.author.id)] = {"message": reason}
        embed=discord.Embed(description=f'{ctx.author.mention}: You\'re now **AFK** with the status: **{afks[str(ctx.author.id)]["message"]}**', color=self.good)
        await ctx.send(embed=embed)
        await asyncio.sleep(1)
        with open('Util/afk.json', 'w') as f:
            json.dump(afks, f, indent=4)
    
    @commands.Cog.listener(name="on_message")
    async def on_afk_say(self, message):
        if message.guild:
            with open('Util/afk.json', 'r') as f:
                afks = json.load(f)
            try:
                if afks[str(message.author.id)]:
                    embed=discord.Embed(description=f"Welcome back, you are no longer AFK!", color=self.color)
                    await message.channel.send(embed=embed)
                    afks.pop(str(message.author.id))
                    with open('Util/afk.json', 'w') as f:
                        json.dump(afks, f, indent=4)
            except KeyError:
                pass
            
    @commands.Cog.listener(name="on_message")
    async def on_afk_ping(self, message):
        if len(message.mentions):
            with open('Util/afk.json', 'r') as f:
                afks = json.load(f)
            for i in message.mentions:
                if str(i.id) in afks and message.author != message.guild.me:
                    embed=discord.Embed(description=f'this user is currently AFK: **{afks[str(i.id)]["message"]}**', color=self.color)
                    await message.channel.send(embed=embed)
 
def setup(bot):
    bot.add_cog(info(bot))
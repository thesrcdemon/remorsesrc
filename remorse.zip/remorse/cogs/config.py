import discord
import traceback
import sys, colorama
from colorama import Fore
from discord.ext import commands
from discord.ext.commands.cooldowns import BucketType
from discord.ext.commands.core import has_permissions
import pymongo
from Util.botcache import BotCache

modules = [
    'antiban',
    'antikick'
]
mongodb = pymongo.MongoClient('mongodb+srv://forge:forge@trace.ltzwf.mongodb.net/discord?retryWrites=true&w=majority')
db = mongodb.get_database("discord").get_collection("welcome")
blacklist = mongodb.get_database("discord").get_collection("blacklist")

def blacklist_check():
    def predicate(ctx):
        author_id = ctx.author.id
        if blacklist.find_one({'user_id': author_id}):
            return False
        return True
    return commands.check(predicate)
class Configuration(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.color = discord.Colour.from_rgb(184,153,255)
        self.good = discord.Colour.from_rgb(164, 235, 120)                                                                
        self.warn = discord.Colour.from_rgb(255,172,28)
        print(f'[\x1b[38;5;213mLOG\x1b[38;5;15m] Loaded COG [\x1b[38;5;213mConfiguration\x1b[38;5;15m]')

    @commands.group(invoke_without_command=True, name="goodbye", help="Shows welcome commands", usage="feautres", aliases=['bye'])
    @blacklist_check()
    @commands.has_permissions()
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def goodbye(self,ctx):
        embed = discord.Embed(title="Sends a message when a user leaves the server", description='```Syntax: ,goodbye (subcommand) <args>\nAliases: bye```',color=self.color)
        embed.add_field(name="__Sub commands__", value="**goodbye config** - Sends the goodbye configuration\n**goodbye embedmessage** - Sets the goodbye embed message\n**goodbye embedtitle** - Sets the goodbye embed title\n**goodbye message** - Sets the goodbye message\n**goodbye embedcolor** - Sets the embed color\n**goodbye variables** - Sends the goodbye variables\ngoodbye channel - Sets the goodbye channel\n**goodbye disable** - Disables the goodbye module\n**goodbye enable** - Enables the goodbye module\n**goodbye embeddisable** - Disable the goodbye embeds\n**goodbye embedenable** - Enable the goodbye embeds\n**goodbye test** - Test the goodbye command", inline=False)
        embed.set_author(name=f"{ctx.author.name}", icon_url=ctx.author.avatar.url)
        await ctx.send(embed=embed)

    @goodbye.command(name="message",help='Sets the goodbye message')
    @blacklist_check()
    @commands.has_permissions(manage_channels=True)
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def message(self,ctx,*,message):
        db.update_one({"guild_id": ctx.guild.id}, {"$set": {"goodbye_message": message}})
        GoodbyeMessage = db.find_one({"guild_id": ctx.guild.id})["goodbye_message"]
        BotCache.goodbyemessage[f'{ctx.guild.id}'] = GoodbyeMessage
        return await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: successfully **set** the goodbye message", color=self.good))

    @goodbye.command(name="variables",help='Sends the goodbye variables')  
    @blacklist_check()
    @commands.has_permissions(manage_channels=True)
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def variables(self, ctx):
        return await ctx.send(embed=discord.Embed(title='Goodbye Variables',description="{user.id}\n{user.mention}\n{user.name}\n{user.tag}\n{server.name}\n{server.icon}\n{server.membercount}", color=self.color))
 
    @goodbye.command(name="channel",help='Sets the goodbye channel')       
    @blacklist_check()
    @commands.has_permissions(manage_channels=True)
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def Goodbye_channel(self, ctx, channel : discord.TextChannel):
        db.update_one({"guild_id": ctx.guild.id}, {"$set": {"goodbye_channel": channel.id}})
        GoodbyeChannel = db.find_one({"guild_id": ctx.guild.id})["goodbye_channel"]
        BotCache.goodbyechannel[f'{ctx.guild.id}'] = GoodbyeChannel
        return await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: set **goodbye** channel to {channel.mention}", color=self.good))



    @goodbye.command(name="disable",help='Disables the goodbye module')  
    @blacklist_check()
    @commands.has_permissions(manage_channels=True)
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def Goodbye_disable(self, ctx):
        db.update_one({"guild_id": ctx.guild.id}, {"$set": {"goodbye_toggle": "Disabled"}})
        GoodbyeToggle = db.find_one({"guild_id": ctx.guild.id})["goodbye_toggle"]
        BotCache.goodbyetoggle[f'{ctx.guild.id}'] = f'{GoodbyeToggle}'
        return await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: **goodbye** toggled **off**", color=self.good))

    @goodbye.command(name="enable",help='Enables the goodbye module')  
    @blacklist_check()
    @commands.has_permissions(manage_channels=True)
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def enable(self, ctx):
        db.update_one({"guild_id": ctx.guild.id}, {"$set": {"goodbye_toggle": "Enabled"}})
        GoodbyeToggle = db.find_one({"guild_id": ctx.guild.id})["goodbye_toggle"]
        BotCache.goodbyetoggle[f'{ctx.guild.id}'] = f'{GoodbyeToggle}'
        return await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: **goodbye** toggled **on**", color=self.good))

    @goodbye.command(name="embedenable",help='Enable the welcome embeds')  
    @blacklist_check()
    @commands.has_permissions(manage_channels=True)
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def embedenable(self, ctx):
        db.update_one({"guild_id": ctx.guild.id}, {"$set": {"goodbye_embed_toggle": "Enabled"}})
        return await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: **goodbye embed** toggled **on**", color=self.good))

    @goodbye.command(name="embeddisable",help='Disable the welcome embeds')       
    @blacklist_check()
    @commands.has_permissions(manage_channels=True)
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def embeddisable(self, ctx):
        db.update_one({"guild_id": ctx.guild.id}, {"$set": {"goodbye_embed_toggle": "Disabled"}})
        return await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: **goodbye embed** has been toggled **off**", color=self.good))

    @goodbye.command(name="embedcolor",help='Sets the embed color')       
    @blacklist_check()
    @commands.has_permissions(manage_channels=True)
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def embedcolor(self, ctx, color):
        db.update_one({"guild_id": ctx.guild.id}, {"$set": {"goodbye_color": color}})
        return await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: updated **goodbye** embed color to **{color}**", color=self.good))

    @goodbye.command(name="embedmessage",help='Sets the welcome embed emssage')
    @blacklist_check()
    @commands.has_permissions(manage_channels=True)
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def embedmessage(self,ctx,*,message):
        db.update_one({"guild_id": ctx.guild.id}, {"$set": {"goodbye_message": message}})
        return await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: set **goodbye** message", color=self.good))

    @goodbye.command(name="embedtitle",help='Sets the welcome embed emssage')
    @blacklist_check()
    @commands.has_permissions(manage_channels=True)
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def embedtitle(self,ctx,*,message):
        db.update_one({"guild_id": ctx.guild.id}, {"$set": {"goodbye_embed_title": message}})
        return await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: set embed **title** to `{message}`", color=self.good))

    @goodbye.command(name="config",help='Sends the goodbye configuration', pass_context=True)  
    @blacklist_check()
    @commands.has_permissions(manage_channels=True)
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def configuration(self, ctx):
        WelcomeToggleFind = db.find_one({"guild_id": ctx.guild.id})['goodbye_toggle']
        WelcomeEmbedToggleFind = db.find_one({"guild_id": ctx.guild.id})['goodbye_embed_toggle']
        WelcomeChannelFind = db.find_one({"guild_id": ctx.guild.id})['goodbye_channel']
        WelcomeEmbedColor = db.find_one({"guild_id": ctx.guild.id})['goodbye_embed_color']



        if WelcomeChannelFind == None:
            channel = '`None Selected`'
        else:
            channel = f'<#{WelcomeChannelFind}>'

        if WelcomeToggleFind == 'Disabled':
            wtoggle = 'Disabled'
        else:
            wtoggle = 'Enabled'

        if WelcomeEmbedToggleFind == 'Disabled':
            wetoggle = 'Disabled'
        else:
            wetoggle = 'Enabled'

        return await ctx.send(embed=discord.Embed(title='Goodbye Config',description=f"Goodbye Status: `{wtoggle}`\nGoodbye Embed Status: `{wetoggle}`\nGoodbye Embed Color: `#{WelcomeEmbedColor}`\nChannel: {channel}", color=self.color))

    @goodbye.command(name='test',help='Test the welcome command')     
    @commands.has_permissions(manage_channels=True)
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def goodbye_test(self, ctx):
        try:
            guild = ctx.guild
            user = ctx.author
            goodbyetoggle1 = db.find_one({"guild_id": guild.id})['goodbye_toggle']
            goodbyetoggle2 = db.find_one({"guild_id": guild.id})['goodbye_embed_toggle']
            channel1 = db.find_one({"guild_id": guild.id})['goodbye_channel']
            message = db.find_one({"guild_id": guild.id})['goodbye_message']

            if goodbyetoggle2 == 'Enabled':
                
                channel = db.find_one({"guild_id": guild.id})['goodbye_channel']
                message = db.find_one({"guild_id": guild.id})['goodbye_message']
                title = db.find_one({"guild_id": guild.id})['goodbye_embed_title']
                colorr = db.find_one({"guild_id": guild.id})['goodbye_embed_color']
                color = int(colorr, 0)
                if title == None:
                    title = 'No title selected'
                if message == None:
                    message = 'No message selected'

                if "{user.id}" in message:
                        message = message.replace("{user.id}", "%s" % (user.id))
                if "{user.mention}" in message:
                    message = message.replace("{user.mention}", "%s" % (user.mention))
                if "{user.tag}" in message:
                    message = message.replace("{user.tag}", "%s" % (user.discriminator))
                if "{user.name}" in message:
                    message = message.replace("{user.name}", "%s" % (user.name))
                if "{user.avatar}" in message:
                    message = message.replace("{user.avatar}", "%s" % (user.avatar_url))
                if "{server.name}" in message:
                    message = message.replace("{server.name}", "%s" % (user.guild.name)) 
                if "{server.membercount}" in message:
                    message = message.replace("{server.membercount}", "%s" % (user.guild.member_count))          
                if "{server.icon}" in message:
                    message = message.replace("{server.icon}", "%s" % (user.guild.icon_url))

                if "{user.id}" in title:
                        title = title.replace("{user.id}", "%s" % (user.id))
                if "{user.mention}" in title:
                    title = title.replace("{user.mention}", "%s" % (user.mention))
                if "{user.tag}" in title:
                    title = title.replace("{user.tag}", "%s" % (user.discriminator))
                if "{user.name}" in title:
                    title = title.replace("{user.name}", "%s" % (user.name))
                if "{user.avatar}" in title:
                    title = title.replace("{user.avatar}", "%s" % (user.avatar_url))
                if "{server.name}" in title:
                    title = title.replace("{server.name}", "%s" % (user.guild.name)) 
                if "{server.membercount}" in title:
                    title = title.replace("{server.membercount}", "%s" % (user.guild.member_count))          
                if "{server.icon}" in title:
                    title = title.replace("{server.icon}", "%s" % (user.guild.icon_url))

                if title == None:
                    embed=discord.Embed(description=f"{message}", color=color)
                    channelsend = self.bot.get_channel(channel)
                    await channelsend.send(embed=embed)
                    await ctx.send(embed=discord.Embed(description="Successfully **tested** the goodbye message", color=self.color))
                    return
        
                if message == None:
                    embed=discord.Embed(title=f"{title}", color=color)
                    channelsend = self.bot.get_channel(channel)
                    await channelsend.send(embed=embed)
                    await ctx.send(embed=discord.Embed(description="Successfully **tested** the goodbye message", color=self.color))
                    return

                if message and title == None:
                    channelsend = self.bot.get_channel(channel)
                    await channelsend.send(message)
                    await ctx.send(embed=discord.Embed(description="Successfully **tested** the goodbye message", color=self.color))
                    return

                embed=discord.Embed(title=f'{title}', description=f"{message}", color=color)
                channelsend = self.bot.get_channel(channel)
                await channelsend.send(embed=embed)
                await ctx.send(embed=discord.Embed(description="Successfully **tested** the goodbye message", color=self.color))
                return


            if goodbyetoggle1 == 'Enabled':
                message = db.find_one({"guild_id": guild.id})['goodbye_message']
                title = db.find_one({"guild_id": guild.id})['goodbye_embed_title']
                colorr = db.find_one({"guild_id": guild.id})['goodbye_embed_color']
                color = int(colorr, 0)
                if title == None:
                    title = 'No title selected'
                if message == None:
                    message = 'No message selected'

                if "{user.id}" in message:
                        message = message.replace("{user.id}", "%s" % (user.id))
                if "{user.mention}" in message:
                    message = message.replace("{user.mention}", "%s" % (user.mention))
                if "{user.tag}" in message:
                    message = message.replace("{user.tag}", "%s" % (user.discriminator))
                if "{user.name}" in message:
                    message = message.replace("{user.name}", "%s" % (user.name))
                if "{user.avatar}" in message:
                    message = message.replace("{user.avatar}", "%s" % (user.avatar_url))
                if "{server.name}" in message:
                    message = message.replace("{server.name}", "%s" % (user.guild.name)) 
                if "{server.membercount}" in message:
                    message = message.replace("{server.membercount}", "%s" % (user.guild.member_count))          
                if "{server.icon}" in message:
                    message = message.replace("{server.icon}", "%s" % (user.guild.icon_url))

                if "{user.id}" in title:
                        title = title.replace("{user.id}", "%s" % (user.id))
                if "{user.mention}" in title:
                    title = title.replace("{user.mention}", "%s" % (user.mention))
                if "{user.tag}" in title:
                    title = title.replace("{user.tag}", "%s" % (user.discriminator))
                if "{user.name}" in title:
                    title = title.replace("{user.name}", "%s" % (user.name))
                if "{user.avatar}" in title:
                    title = title.replace("{user.avatar}", "%s" % (user.avatar_url))
                if "{server.name}" in title:
                    title = title.replace("{server.name}", "%s" % (user.guild.name)) 
                if "{server.membercount}" in title:
                    title = title.replace("{server.membercount}", "%s" % (user.guild.member_count))          
                if "{server.icon}" in title:
                    title = title.replace("{server.icon}", "%s" % (user.guild.icon_url))
                channel1 = db.find_one({"guild_id": guild.id})['goodbye_channel']
                channelsend = self.bot.get_channel(channel1)
                await channelsend.send(message)
                await ctx.send(embed=discord.Embed(description="successfully **tested** the goodbye message", color=self.good))
                return

            
        except Exception:
            print(traceback.format_exc())
            print(sys.exc_info()[2])

    @commands.group(invoke_without_command=True, name="welcome", help="Shows welcome commands", aliases=['wlc', 'welc'])
    @blacklist_check()
    @commands.has_permissions()
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def welcome(self,ctx):
        embed = discord.Embed(title="Sends a message when a user joins the server", description='```Syntax: ,welcome (subcommand) <args>\nAliases: wlc, welc```',color=self.color)
        embed.add_field(name="__Sub commands__", value="**welcome config** - Sends the welcome configuration\n**welcome embedmessage** - Sets the welcome embed message\n**welcome embedtitle** - Sets the welcome embed title\n**welcome message** - Sets the welcome message\n**welcome embedcolor** - Sets the embed color\n**welcome variables** - Sends the welcome variables\n**welcome channel** - Sets the welcome channel\n**welcome disable** - Disables the welcome module\n**welcome enable** - Enables the welcome module\n**welcome embeddisable** - Disable the welcome embeds\n**welcome embedenable** - Enable the welcome embeds\n**welcome test** - Test the welcome command", inline=False)
        embed.set_author(name=f"{ctx.author.name}", icon_url=ctx.author.avatar.url)
        await ctx.send(embed=embed)

    @welcome.command(name="message",help='Sets the welcome emssage')
    @blacklist_check()
    @commands.has_permissions(manage_channels=True)
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def welcome_message(self,ctx,*,message):
        db.update_one({"guild_id": ctx.guild.id}, {"$set": {"welcome_message": message}})
        WelcomeMessage = db.find_one({"guild_id": ctx.guild.id})["welcome_message"]
        BotCache.welcomemessage[f'{ctx.guild.id}'] = WelcomeMessage

        return await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: successfully **set** the welcome message", color=self.good))

    @welcome.command(name="variables",help='Sends the welcome variables')      
    @blacklist_check()
    @commands.has_permissions(manage_channels=True)
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def welcome_variables(self, ctx):
        return await ctx.send(embed=discord.Embed(title='Welcome Variables',description="{user.id}\n{user.mention}\n{user.name}\n{user.tag}\n{server.name}\n{server.icon}\n{server.membercount}", color=self.color))
 
    @welcome.command(name="config",help='Sends the welcome configuration')     
    @blacklist_check()
    @commands.has_permissions(manage_channels=True)
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def welcome_configurationN(self, ctx):
        WelcomeToggleFind = db.find_one({"guild_id": ctx.guild.id})['welcome_toggle']
        WelcomeEmbedToggleFind = db.find_one({"guild_id": ctx.guild.id})['welcome_embed_toggle']
        WelcomeChannelFind = db.find_one({"guild_id": ctx.guild.id})['welcome_channel']
        WelcomeEmbedColor = db.find_one({"guild_id": ctx.guild.id})['welcome_embed_color']



        if WelcomeChannelFind == None:
            channel = '`None Selected`'
        else:
            channel = f'<#{WelcomeChannelFind}>'

        if WelcomeToggleFind == 'Disabled':
            wtoggle = 'Disabled'
        else:
            wtoggle = 'Enabled'

        if WelcomeEmbedToggleFind == 'Disabled':
            wetoggle = 'Disabled'
        else:
            wetoggle = 'Enabled'

        return await ctx.send(embed=discord.Embed(title='Welcome Config',description=f"Welcome Status: `{wtoggle}`\nWelcome Embed Status: `{wetoggle}`\nWelcome Embed Color: `#{WelcomeEmbedColor}`\nChannel: {channel}", color=self.color))

    @welcome.command(name="channel",help='Set the welcome channel')       
    @blacklist_check()
    @commands.has_permissions(manage_channels=True)
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def welcome_channel(self, ctx, channel : discord.TextChannel):
        db.update_one({"guild_id": ctx.guild.id}, {"$set": {"welcome_channel": channel.id}})
        WelcomeChannel = db.find_one({"guild_id": ctx.guild.id})["welcome_channel"]
        BotCache.welcomechannel[f'{ctx.guild.id}'] = WelcomeChannel
        return await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: set **welcome** channel to {channel.mention}", color=self.good))
    

    @welcome.command(name="disable",help='Disable the welcome module')       
    @blacklist_check()
    @commands.has_permissions(manage_channels=True)
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def welcome_disable(self, ctx):
        db.update_one({"guild_id": ctx.guild.id}, {"$set": {"welcome_toggle": "Disabled"}})
        return await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: **welcome** toggled **off**", color=self.good))

    @welcome.command(name="enable",help='Enable the welcome module')    
    @blacklist_check()
    @commands.has_permissions(manage_channels=True)
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def welcome_enable(self, ctx):
        db.update_one({"guild_id": ctx.guild.id}, {"$set": {"welcome_toggle": "Enabled"}})
        WelcomeToggle = db.find_one({"guild_id": ctx.guild.id})["welcome_toggle"]
        BotCache.welcometoggle[f'{ctx.guild.id}'] = f'{WelcomeToggle}'
        return await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: **welcome** toggled **on**", color=self.good))
#-------------------------------------------------------------------------------------------------------------------------------------------------------

    @welcome.command(name="embedenable",help='Enable the welcome embeds')  
    @blacklist_check()
    @commands.has_permissions(manage_channels=True)
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def welcome_embedenable(self, ctx):
        db.update_one({"guild_id": ctx.guild.id}, {"$set": {"welcome_embed_toggle": "Enabled"}})
        return await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: **welcome embed** has been toggled **on**", color=self.good))

    @welcome.command(name="embeddisable",help='Disable the welcome embeds')       
    @blacklist_check()
    @commands.has_permissions(manage_channels=True)
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def welcome_embeddisable(self, ctx):
        db.update_one({"guild_id": ctx.guild.id}, {"$set": {"welcome_embed_toggle": "Disabled"}})
        return await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: **welcome embed** has been toggled **off**", color=self.good))

    @welcome.command(name="embedcolor",help='Sets the embed color')       
    @blacklist_check()
    @commands.has_permissions(manage_channels=True)
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def welcome_embedcolor(self, ctx, color):
        db.update_one({"guild_id": ctx.guild.id}, {"$set": {"welcome_embed_color": color}})
        return await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: updated **welcome** embed color to **{color}**", color=self.good))

    @welcome.command(name="embedmessage",help='Sets the welcome embed emssage')
    @blacklist_check()
    @commands.has_permissions(manage_channels=True)
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def embedmessage(self,ctx,*,message):
        db.update_one({"guild_id": ctx.guild.id}, {"$set": {"welcome_embed_message": message}})
        return await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: set **welcome message** to `{message}`", color=self.good))

    @welcome.command(name="embedtitle",help='Sets the welcome embed emssage')
    @blacklist_check()
    @commands.has_permissions(manage_channels=True)
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def embedtitle(self,ctx,*,message):
        db.update_one({"guild_id": ctx.guild.id}, {"$set": {"welcome_embed_title": message}})
        return await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: updated **welcome embed** title to `{message}`", color=self.good))

#-------------------------------------------------------------------------------------------------------------------------------------------------------
    #user = ctx.author
    @welcome.command(name='test',help='Test the welcome command')     
    @commands.has_permissions(manage_channels=True)
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def welcome_test(self, ctx):
        try:
            guild = ctx.guild
            user = ctx.author
            goodbyetoggle1 = db.find_one({"guild_id": guild.id})['welcome_toggle']
            goodbyetoggle2 = db.find_one({"guild_id": guild.id})['welcome_embed_toggle']
            channel1 = db.find_one({"guild_id": guild.id})['welcome_channel']
            message = db.find_one({"guild_id": guild.id})['welcome_message']

            if goodbyetoggle2 == 'Enabled':
                
                channel = db.find_one({"guild_id": guild.id})['welcome_channel']
                message = db.find_one({"guild_id": guild.id})['welcome_message']
                title = db.find_one({"guild_id": guild.id})['welcome_embed_title']
                colorr = db.find_one({"guild_id": guild.id})['welcome_embed_color']
                color = int(colorr, 0)
                if title == None:
                    title = 'No title selected'
                if message == None:
                    message = 'No message selected'

                if "{user.id}" in message:
                        message = message.replace("{user.id}", "%s" % (user.id))
                if "{user.mention}" in message:
                    message = message.replace("{user.mention}", "%s" % (user.mention))
                if "{user.tag}" in message:
                    message = message.replace("{user.tag}", "%s" % (user.discriminator))
                if "{user.name}" in message:
                    message = message.replace("{user.name}", "%s" % (user.name))
                if "{user.avatar}" in message:
                    message = message.replace("{user.avatar}", "%s" % (user.avatar_url))
                if "{server.name}" in message:
                    message = message.replace("{server.name}", "%s" % (user.guild.name)) 
                if "{server.membercount}" in message:
                    message = message.replace("{server.membercount}", "%s" % (user.guild.member_count))          
                if "{server.icon}" in message:
                    message = message.replace("{server.icon}", "%s" % (user.guild.icon_url))

                if "{user.id}" in title:
                        title = title.replace("{user.id}", "%s" % (user.id))
                if "{user.mention}" in title:
                    title = title.replace("{user.mention}", "%s" % (user.mention))
                if "{user.tag}" in title:
                    title = title.replace("{user.tag}", "%s" % (user.discriminator))
                if "{user.name}" in title:
                    title = title.replace("{user.name}", "%s" % (user.name))
                if "{user.avatar}" in title:
                    title = title.replace("{user.avatar}", "%s" % (user.avatar_url))
                if "{server.name}" in title:
                    title = title.replace("{server.name}", "%s" % (user.guild.name)) 
                if "{server.membercount}" in title:
                    title = title.replace("{server.membercount}", "%s" % (user.guild.member_count))          
                if "{server.icon}" in title:
                    title = title.replace("{server.icon}", "%s" % (user.guild.icon_url))

                if title == None:
                    embed=discord.Embed(description=f"{message}", color=color)
                    channelsend = self.bot.get_channel(channel)
                    await channelsend.send(embed=embed)
                    await ctx.send(embed=discord.Embed(description="successfully **tested** the welcome message", color=self.good))
                    return
        
                if message == None:
                    embed=discord.Embed(title=f"{title}", color=color)
                    channelsend = self.bot.get_channel(channel)
                    await channelsend.send(embed=embed)
                    await ctx.send(embed=discord.Embed(description="successfully **tested** the welcome message", color=self.good))
                    return

                if message and title == None:
                    channelsend = self.bot.get_channel(channel)
                    await channelsend.send(message)
                    await ctx.send(embed=discord.Embed(description="successfully **tested** the welcome message", color=self.good))
                    return

                embed=discord.Embed(title=f'{title}', description=f"{message}", color=color)
                channelsend = self.bot.get_channel(channel)
                await channelsend.send(embed=embed)
                await ctx.send(embed=discord.Embed(description="successfully **tested** the welcome message", color=self.good))
                return


            if goodbyetoggle1 == 'Enabled':
                message = db.find_one({"guild_id": guild.id})['welcome_message']
                title = db.find_one({"guild_id": guild.id})['welcome_embed_title']
                colorr = db.find_one({"guild_id": guild.id})['welcome_embed_color']
                color = int(colorr, 0)
                if title == None:
                    title = 'No title selected'
                if message == None:
                    message = 'No message selected'

                if "{user.id}" in message:
                        message = message.replace("{user.id}", "%s" % (user.id))
                if "{user.mention}" in message:
                    message = message.replace("{user.mention}", "%s" % (user.mention))
                if "{user.tag}" in message:
                    message = message.replace("{user.tag}", "%s" % (user.discriminator))
                if "{user.name}" in message:
                    message = message.replace("{user.name}", "%s" % (user.name))
                if "{user.avatar}" in message:
                    message = message.replace("{user.avatar}", "%s" % (user.avatar_url))
                if "{server.name}" in message:
                    message = message.replace("{server.name}", "%s" % (user.guild.name)) 
                if "{server.membercount}" in message:
                    message = message.replace("{server.membercount}", "%s" % (user.guild.member_count))          
                if "{server.icon}" in message:
                    message = message.replace("{server.icon}", "%s" % (user.guild.icon_url))

                if "{user.id}" in title:
                        title = title.replace("{user.id}", "%s" % (user.id))
                if "{user.mention}" in title:
                    title = title.replace("{user.mention}", "%s" % (user.mention))
                if "{user.tag}" in title:
                    title = title.replace("{user.tag}", "%s" % (user.discriminator))
                if "{user.name}" in title:
                    title = title.replace("{user.name}", "%s" % (user.name))
                if "{user.avatar}" in title:
                    title = title.replace("{user.avatar}", "%s" % (user.avatar_url))
                if "{server.name}" in title:
                    title = title.replace("{server.name}", "%s" % (user.guild.name)) 
                if "{server.membercount}" in title:
                    title = title.replace("{server.membercount}", "%s" % (user.guild.member_count))          
                if "{server.icon}" in title:
                    title = title.replace("{server.icon}", "%s" % (user.guild.icon_url))
                channel1 = db.find_one({"guild_id": guild.id})['welcome_channel']
                channelsend = self.bot.get_channel(channel1)
                await channelsend.send(message)
                await ctx.send(embed=discord.Embed(description="successfully **tested** the welcome message", color=self.good))
                return

            
        except Exception:
            print(traceback.format_exc())
            # or
            print(sys.exc_info()[2])

# -------------------------------------------------------------------------------------------------------------------------
# -------------------------------------------------------------------------------------------------------------------------

def setup(bot):
    bot.add_cog(Configuration(bot))

import discord 
import colorama 
import orjson 
import os 
import json 
from discord.ext import commands
from discord.ui import Button, View
from colorama import Fore



class sp(commands.Cog):
    def __init__(self, client):
        self.client = client
        self.color = 0x2f3136
        self.good = discord.Colour.from_rgb(164, 235, 120)                                                                
        self.bad = discord.Colour.from_rgb(255, 100, 100)
        self.warn = discord.Colour.from_rgb(255,172,28)
        print(f"{Fore.CYAN}[Status] Cog Loaded: Spotify" + Fore.RESET)

    
    @commands.command(aliases=['sp'])
    async def spotify(self, ctx, member : discord.Member=None):
        member = member or ctx.author
        spot = next((activity for activity in member.activities if isinstance(activity, discord.Spotify)), None)
        if spot == None:
            await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: **{member.name}** not listening to anything", color=self.warn))
            return
        spbu = Button(label="Song Link", url=f"https://open.spotify.com/track/{spot.track_id}")
        view = View(spbu)
        e = discord.Embed(title=f"***{spot.title}***",url=f"https://open.spotify.com/track/{spot.track_id}",description=f"album: **{spot.album}**\nartist: **{spot.artist}**", color=self.color)
        e.set_author(name=f"{member.name}")
        e.set_thumbnail(url=spot.album_cover_url)
        e.set_footer(text=f'Spotify — {spot.artist} on {spot.title}')
        message = await ctx.send(embed=e, view=view)
        await message.add_reaction("🔥")
        await message.add_reaction("🗑️")

def setup(bot):
    bot.add_cog(sp(bot))
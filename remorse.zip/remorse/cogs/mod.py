import discord
import colorama 
import os
import json
import requests
from discord.ext import commands
import datetime 
import humanfriendly
from colorama import Fore
import pymongo, math, aiohttp, io
mongodb = pymongo.MongoClient('mongodb+srv://forge:forge@trace.ltzwf.mongodb.net/discord?retryWrites=true&w=majority')
blacklist = mongodb.get_database("discord").get_collection("blacklist")

def blacklist_check():
    def predicate(ctx):
        author_id = ctx.author.id
        if blacklist.find_one({'user_id': author_id}):
            return False
        return True
    return commands.check(predicate)

class mod(commands.Cog):
    def __init__(self, client):
        self.client = client
        #self.color = discord.Colour.from_rgb(105,145,157)
        self.color = discord.Colour.from_rgb(184,153,255)
        #self.color = 0x2f3136
        self.good = discord.Colour.from_rgb(164, 235, 120)                                                                
        self.warn = discord.Colour.from_rgb(255,172,28)
        print(f'[\x1b[38;5;213mLOG\x1b[38;5;15m] Loaded COG [\x1b[38;5;213mModeration\x1b[38;5;15m]')
    
    
    @commands.command(
        name="lock",
        description="locks channel"
    )
    @blacklist_check()
    @commands.cooldown(1,2,commands.BucketType.user)
    @commands.has_permissions(manage_channels=True)
    async def lock(self, ctx, channel : discord.TextChannel=None):
        if channel is None: channel = ctx.channel
        try:
            overwrite = ctx.channel.overwrites_for(ctx.guild.default_role)
            overwrite.send_messages = False
            await ctx.channel.set_permissions(ctx.guild.default_role, overwrite=overwrite)
            await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: {channel.mention} has been placed into **lockdown**", color=self.good))
        except Exception as e:
            await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: {e}", color=self.warn))
        else:
            pass
    
    @lock.error
    async def lock_error(self, ctx, error):
        if isinstance(error, commands.MissingPermissions):
            return await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: **{ctx.invoked_with}** requires the `manage channels` permission", color=self.warn))

    @commands.command(
        name="unlock",
        description="unlocks channel"
    )
    @blacklist_check()
    @commands.cooldown(1,2,commands.BucketType.user)
    @commands.has_permissions(manage_channels=True)
    async def unlock(self, ctx, channel : discord.TextChannel=None):
        if channel is None: channel = ctx.channel
        try:
            overwrite = ctx.channel.overwrites_for(ctx.guild.default_role)
            overwrite.send_messages = True
            await ctx.channel.set_permissions(ctx.guild.default_role, overwrite=overwrite)
            await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: {channel.mention} has been removed from **lockdown**", color=self.good))
        except Exception as e:
            await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: {e}", color=self.warn))
        else:
            pass
    
    @unlock.error
    async def unlock_error(self, ctx, error):
        if isinstance(error, commands.MissingPermissions):
            return await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: **{ctx.invoked_with}** requires the `manage channels` permission", color=self.warn))
        

    @commands.command(
        name="ban",
        description="bans member from guild",
        aliases=['banish']
    )
    @blacklist_check()
    @commands.has_permissions(ban_members=True)
    async def ban(self, ctx, member:discord.Member=None, *, reason=None):
        if member == None:
            e = discord.Embed(title="ban", description="Ban a user", color=self.color)
            e.add_field(name="Usage", value="```ban (user) [reason]```", inline=False)
            e.add_field(name="Alliases", value="```banish```", inline=False)
            e.set_footer(text="Module: Moderation")
            e.set_author(name=f"{ctx.author}", icon_url=f"{ctx.author.avatar.url}")
            await ctx.send(embed=e)
        elif reason == None:
            reason == "N/A"
            await member.ban(reason=reason)
            await ctx.send(':thumbsup:')
        elif member == ctx.guild.owner:
            await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: you **cannot** ban **{ctx.guild.owner}**", color=self.warn))
        elif member == ctx.author:
            await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: you **cannot** ban **yourself**", color=self.warn))
        elif member.top_role >= ctx.author.top_role:    
            await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: you **cannot** ban **{member}**", color=self.warn))
        else:
            await member.ban(reason=reason)
            await ctx.send(f':thumbsup:')#ill finish this later 
    @ban.error
    async def ban_error(self, ctx, error):
        if isinstance(error, commands.MissingPermissions):
            return await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: **{ctx.invoked_with}** requires the `ban members` permission", color=self.warn))
    
    @commands.command(
        name="kick",
        description="removes member from guild",
        aliases=['boot']
    )
    @blacklist_check()
    @commands.has_permissions(kick_members=True)
    async def kick(self, ctx, member : discord.Member=None, *, reason=None):
        if member == None:
            e = discord.Embed(title="kick", description="Kick a user", color=self.color)
            e.add_field(name="Usage", value="```kick (user) [reason]```", inline=False)
            e.add_field(name="Alliases", value="```boot```", inline=False)
            e.set_footer(text="Module: Moderation")
            e.set_author(name=f"{ctx.author}", icon_url=f"{ctx.author.avatar.url}")
            await ctx.send(embed=e)
        elif reason == None:
            reason == "N/A"
            await member.kick(reason=reason) #make sure they cant ban people above them lmao ye ik
            await ctx.send(f':thumbsup:')
        elif member.top_role >= ctx.author.top_role:    
            await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: you **cannot** ban **{member}**", color=self.warn))           
        elif member == ctx.guild.owner:
            await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: you **cannot** kick **{ctx.guild.owner}**", color=self.warn))
        elif member == ctx.author:
            await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: you **cannot** kick **yourself**", color=self.warn))
        else:
            await member.kick(reason=reason)
            await ctx.send(f':thumbsup:')
    
    @kick.error
    async def kick_error(self, ctx, error):
        if isinstance(error, commands.MissingPermissions):
            return await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: **{ctx.invoked_with}** requires the `kick members` permission", color=self.warn))
    
    @commands.command(
        name="mute",
        description="mutes given member"
    )
    @blacklist_check()
    @commands.cooldown(1,2,commands.BucketType.user)
    @commands.has_permissions(manage_roles=True)
    async def mute(self, ctx, member : discord.Member=None, *, tim):
       k = humanfriendly.parse_timespan(tim)
       if member == ctx.author:
           await ctx.send(f'no')
       elif member.top_role >= ctx.author.top_role:
           await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: cant mute someone above you", color=self.warn))
       elif member == ctx.guild.owner:
           await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: you **cannot** mute **{ctx.guild.owner}**", color=self.warn))
       else:
           await member.timeout(until = discord.utils.utcnow()+datetime.timedelta(seconds=k))
           e = discord.Embed(description=f"{ctx.author.mention}: muted **{member}** for **{tim}**", color=self.good)#idk wht it should say
           await ctx.send(embed=e)
    
    @mute.error
    async def mute_error(self, ctx, error):
        if isinstance(error, commands.MissingPermissions):
            return await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: **{ctx.invoked_with}** requires the `manage roles` permission", color=self.warn))

    @commands.command(
        name="unmute",
        description="unmutes given member"
    )
    @blacklist_check()
    @commands.cooldown(1,2,commands.BucketType.user)
    @commands.has_permissions(manage_roles=True)
    async def unmute(self, ctx, member : discord.Member=None):
        await member.timeout(until = None)
        e = discord.Embed(description=f"{ctx.author.mention}: unmuted **{member}**", color=self.good)#idk wht it should say
        await ctx.send(embed=e)
    
    @unmute.error
    async def unmute_error(self, ctx, error):
        if isinstance(error, commands.MissingPermissions):
            return await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: **{ctx.invoked_with}** requires the `manage roles` permission", color=self.warn))
    
    @commands.guild_only()
    @blacklist_check()
    @commands.cooldown(1,2,commands.BucketType.user)
    @commands.group(aliases=['e', 'em','emote'], description=f"displays emote commands for guild")
    async def emoji(self, ctx):
     if ctx.invoked_subcommand is None:
         em = discord.Embed(title="Command: emoji", description="manage server emojis", color=self.color, timestamp=ctx.message.created_at)
         em.add_field(name="sub commands", value="```,emoji add\n,emoji enlarge\n,emoji list\n,emoji remove```", inline=False)
         em.add_field(name="aliases", value="e, em, emote")
         em.add_field(name="permissions", value="manage_emojis")
         em.add_field(name="parameters", value="cubcommand, emote")
         em.add_field(name="usage", value="```Syntax: ,emoji [subcommand] [emoji]\nExample: ,emoji add :exit:```", inline=False)
         em.set_author(name="remorse help", icon_url=ctx.author.avatar.url)
         em.set_footer(text="Module: Emoji")
         await ctx.send(embed=em)
    
    @commands.guild_only()
    @blacklist_check()
    @emoji.command()
    async def list(self, ctx):
        msg = ""
        for x in ctx.guild.emojis:
            if x.animated:
                msg += "<a:{}:{}> ".format(x.name, x.id)
            else:
                msg += "<:{}:{}> ".format(x.name, x.id)
        if msg == "":
            await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: there are **0** emotes in this guild", color=self.warn))
            return
        else:
            i = 0 
            n = 2000
            for x in range(math.ceil(len(msg)/2000)):
                while msg[n-1:n] != " ":
                    n -= 1
                s=discord.Embed( color=self.color, description=msg[i:n])
                i += n
                n += n
                if i <= 2000:
                    s.set_author(name="{} Emojis".format(ctx.guild.name), icon_url=ctx.guild.icon.url)
                await ctx.send(embed=s)
    
    @commands.command(
        name="setbanner",
        description="changes guilds banner"
    )
    @commands.has_permissions(manage_guild=True)
    async def setbanner(self, ctx, url: str):
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as resp:
                if resp.status != 200:
                    return await ctx.send(embed = discord.Embed(description=f"{ctx.author.mention}: im **unable** to render this **image**", color=self.warn))
                data = io.BytesIO(await resp.read())
                await ctx.message.guild.edit(banner=data.read())
                await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: updated this guild's banner to **[this image]({url})**", color=self.good))
    
    @setbanner.error
    async def setbanner_error(self, ctx, error):
        if isinstance(error, commands.MissingPermissions):
            return await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: **{ctx.invoked_with}** requires the `manage guild` permission", color=self.warn))

    @commands.command(
        name="seticon",
        description="changes guilds icon"
    )
    @commands.has_permissions(manage_guild=True)
    async def seticon(self, ctx, url: str):
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as resp:
                if resp.status != 200:
                    return await ctx.send(embed = discord.Embed(description=f"{ctx.author.mention}: im **unable** to render this **image**", color=self.warn))
                data = io.BytesIO(await resp.read())
                await ctx.message.guild.edit(icon=data.read())
                await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: updated this guild's icon to **[this image]({url})**", color=self.good))
    @seticon.error
    async def seticon_error(self, ctx, error):
        if isinstance(error, commands.MissingPermissions):
            return await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: **{ctx.invoked_with}** requires the `manage guild` permission", color=self.warn))
    
    @commands.command(
        name="unban",
        description="unbans banned member"
    )
    @blacklist_check()
    @commands.has_permissions(ban_members=True)
    async def unban(self, ctx, userid):
        if ctx.author.id == userid:
            await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: you **cannot** unban **yourslef**.", color=self.warn))
        else:
            try:
                user = discord.Object(id=userid)
                await ctx.guild.unban(user)
                await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: **{userid}** has been unbanned", color=self.good))
            except Exception as e:
                await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: {e}", color=self.warn))
    
    @unban.error
    async def unban_error(self, ctx, error):
        if isinstance(error, commands.MissingPermissions):
            return await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: **{ctx.invoked_with}** requires the `ban members` permission", color=self.warn))
                
    @commands.group(
        name="purge",
        description="purges messages"
    )
    @commands.guild_only()
    @blacklist_check()
    @commands.cooldown(1,2,commands.BucketType.user)
    @commands.has_permissions(manage_messages=True)
    async def purge(self, ctx):
        """ Removes messages from the current server. """
        if ctx.invoked_subcommand is None:
            e = discord.Embed(title="Command: purge", description=f"purge messages", color=self.color)
            e.add_field(name="Sub Commands", value="```,purge embeds <amount>\n,purge files <amount>\n,purge mentions <amount>\n,purge images <amount>\n,purge user <user> <amount>\n,purge bots <amount>\n,purge users <amount>```", inline=False)
            e.add_field(name="Aliases", value="N/A")
            e.add_field(name="Permissions", value="Manage Messages")
            e.add_field(name="Arguments", value="Subcommand, Amount")
            e.add_field(name="Command Usage", value="```Syntax: ,purge [subcommand] [amount]\nExample: ,purge forge 27```")
            e.set_author(name="remorse help", icon_url=ctx.author.avatar.url)
            e.set_footer(text="Module: Moderation")
            await ctx.send(embed=e)

    async def do_removal(self, ctx, limit, predicate, *, before=None, after=None, message=True):
        if limit > 2000:
            return await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: too many messages `({limit}/2000)`", color=self.warn))

        if not before:
            before = ctx.message
        else:
            before = discord.Object(id=before)

        if after:
            after = discord.Object(id=after)

        try:
            deleted = await ctx.channel.purge(limit=limit, before=before, after=after, check=predicate)
        except discord.Forbidden:
            return await ctx.send(embed=discord.Embed(description=f'{ctx.author.mention}: im missing `manage messages` permissions', color=self.warn))
        except discord.HTTPException as e:
            return await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: {e}", color=self.warn))

        deleted = len(deleted)
        if message is True:
            await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: Purged **{deleted}** message{'' if deleted == 1 else 's'}", color=self.good))
            #await ctx.send(f"🚮 Successfully removed {deleted} message{'' if deleted == 1 else 's'}.")

    @purge.command()
    async def embeds(self, ctx, search=100):
        """Removes messages that have embeds in them."""
        await self.do_removal(ctx, search, lambda e: len(e.embeds))

    @purge.command()
    async def files(self, ctx, search=100):
        """Removes messages that have attachments in them."""
        await self.do_removal(ctx, search, lambda e: len(e.attachments))

    @purge.command()
    async def mentions(self, ctx, search=100):
        """Removes messages that have mentions in them."""
        await self.do_removal(ctx, search, lambda e: len(e.mentions) or len(e.role_mentions))

    @purge.command()
    async def images(self, ctx, search=100):
        """Removes messages that have embeds or attachments."""
        await self.do_removal(ctx, search, lambda e: len(e.embeds) or len(e.attachments))

    @purge.command()
    async def user(self, ctx, member: discord.Member, search=100):
        """Removes all messages by the member."""
        await self.do_removal(ctx, search, lambda e: e.author == member)

    @purge.command(name="bots")
    async def _bots(self, ctx, search=100, prefix=None):
        """Removes a bot user's messages and messages with their optional prefix."""

        getprefix = prefix if prefix else self.config["prefix"]

        def predicate(m):
            return (m.webhook_id is None and m.author.bot) or m.content.startswith(tuple(getprefix))

        await self.do_removal(ctx, search, predicate)

    @purge.command(name="users")
    async def _users(self, ctx, prefix=None, search=100):
        """Removes only user messages. """

        def predicate(m):
            return m.author.bot is False

        await self.do_removal(ctx, search, predicate)

    """@commands.command(
        name="purge",
        description="purges <amount> messages in channel"
    )
    @commands.has_permissions(manage_messages=True)
    async def purge(self, ctx, amount=0):
        if amount == 0:
            await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: amount cannot be **0**", color=self.warn))
        else:
            try:
                await ctx.channel.purge(limit=amount)
                await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: Purged **{amount}** messages", color=self.good))
            except Exception as e:
                await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: {e}", color=self.warn))
    """
    @purge.error
    async def purge_error(self, ctx, error):
        if isinstance(error, commands.MissingPermissions):
            return await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: **{ctx.invoked_with}** requires the `manage messages` permission", color=self.warn))
                

    @emoji.command(
        name="remove",
        description="removes given emoji from guild"
    )
    @blacklist_check()
    @commands.bot_has_permissions(manage_emojis=True)
    @commands.has_permissions(manage_emojis=True)
    async def remove(self, ctx, emote : discord.Emoji = None):
     if emote == None:
        await ctx.send(f':thumbsdown: - please provide a valid emoji to delete.')
        return
        
     await ctx.send(embed=discord.Embed(description=f'{ctx.author.mention}: Deleted **emoji** [{emote.name}]({emote.url}) from **{ctx.guild.name}**',color=self.good))
     await emote.delete()
     return
    @remove.error
    async def remove_error(self, ctx, error):
        if isinstance(error, commands.MissingPermissions):
            return await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: **{ctx.invoked_with}** requires the `manage emojis` permission", color=self.warn))
    
    @commands.guild_only()
    @emoji.command(
        name="add",
        description="adds given emoji to guild"
    )
    @blacklist_check()
    @commands.has_permissions(manage_emojis=True)
    async def add(self, ctx, emote = None):
     if emote == None:
        await ctx.send(f'witch emote would you like me to add?')
        return
     try:
        if emote[0] == '<':
            name = emote.split(':')[1]
            emoji_name = emote.split(':')[2][:-1]
            anim = emote.split(':')[0]
            if anim == '<a':
                url = f'https://cdn.discordapp.com/emojis/{emoji_name}.gif'
            else:
                url = f'https://cdn.discordapp.com/emojis/{emoji_name}.png'
            try:
                response = requests.get(url) 
                img = response.content
                emote = await ctx.guild.create_custom_emoji(name=name, image=img)
                await ctx.send(embed=discord.Embed(description=f'{ctx.author.mention}: Added **emoji** [{emote.name}]({url}) to **{ctx.guild.name}**',color=self.good))
            except Exception as e:
                em = discord.Embed(description=f"{ctx.author.mention}: {e}", color=discord.Colour.from_rgb(255,172,28))
                await ctx.send(embed=em)
                return
        #else:
            #await ctx.send(f':thumbsdown: - please provide a valid emoji to add.')
            #retur
     except Exception as e:
        em = discord.Embed(description=f"{ctx.author.mention}: {e}", color=discord.Colour.from_rgb(255,172,28))
        await ctx.send(embed=em)
        return
    
    @add.error
    async def add_error(self, ctx, error):
        if isinstance(error, commands.MissingPermissions):
            return await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: **{ctx.invoked_with}** requires the `manage emojis` permission", color=self.warn))

    @emoji.command()
    @blacklist_check()
    @commands.guild_only()
    async def enlarge(self, ctx, emoji = None): 
      if emoji == None:
        await ctx.send(f':thumbsdown: - please provide a valid emoji to enlarge.')
        return
      if emoji[0] == '<':
        name = emoji.split(':')[1]
        emoji_name = emoji.split(':')[2][:-1]
        anim = emoji.split(':')[0]
        if anim == '<a':
            url = f'https://cdn.discordapp.com/emojis/{emoji_name}.gif'
        else:
            url = f'https://cdn.discordapp.com/emojis/{emoji_name}.png'
      else:
        await ctx.send(embed=discord.Embed(description="unable to use that emoji, make sure you're using a unicode emoji or one from this server", color=self.color))
        return
      await ctx.send(f'{url}')
    
    @commands.command(
        name="nuke",
        description="deletes then re-creates channel"
    )
    @commands.cooldown(1,3,commands.BucketType.user)
    @commands.has_permissions(manage_channels=True)
    async def nuke(self, ctx):
        channel_id = ctx.channel.id
        channel = self.client.get_channel(channel_id)
        new_channel = await ctx.guild.create_text_channel(name=channel.name, topic=channel.topic, overwrites=channel.overwrites, nsfw=channel.nsfw, category=channel.category, slowmode_delay=channel.slowmode_delay, position=channel.position)
        await channel.delete()
        await new_channel.send(embed=discord.Embed(description=f"{ctx.author.mention}: **{channel.name}** has been **nuked**", color=self.good))
    
    @commands.command(
        name="setprefix",
        description="sets bot prefix for guild (not finished)"
    )
    @commands.cooldown(1,8,commands.BucketType.user)
    @commands.has_permissions(administrator=True)
    async def setprefix(self, ctx, prefix):
        with open("prefixes.json", "r") as f:
            prefixes = json.load(f)
            prefixes[str(ctx.guild.id)] = prefix
            with open("prefixes.json", "w") as f:
                json.dump(prefixes, f, indent=4)
                await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: updated server prefix to **{prefix}**", color=self.good))

    @nuke.error
    async def nuke_error(self, ctx, error):
        if isinstance(error, commands.MissingPermissions):
            return await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: **{ctx.invoked_with}** requires the `manage channels` permission", color=self.warn))
    
    @commands.command(
      name="unbanall",
      description="removes all bans in the server",
      usage="unbanall",
      aliases=["massunban", "purgebans", "clearbans", "cb"]
    )
    @commands.cooldown(1,8,commands.BucketType.user)
    @commands.has_permissions(ban_members=True)
    async def unbanall(self, ctx):
        if not ctx.message.guild:
            return
        else:          
            banlist = await ctx.guild.bans()
            members = [str(f'`{users.user}` **|** `{users.user.id}`') for users in banlist]
            #ping = float(f'0.{int(self.bot.latency * 1000)}') / 3
            #est_time = round(len(members) * ping)
            for users in banlist:
                try:
                    await ctx.guild.unban(user=users.user)
                except Exception as e:
                    await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: {e}", color=self.warn))    
            if len(members) == 0:
                await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: theres no **banned** users", color=self.warn))
                return

            
            em = discord.Embed(description=f"{ctx.author.mention}: unbanned **{len(members)}** members", colour=self.good)
            await ctx.send(embed=em)
    
    @unban.error
    async def unban_error(self, ctx, error):
        if isinstance(error, commands.MissingPermissions):
            return await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: **{ctx.invoked_with}** requires the `manage channels` permission", color=self.warn))
    
    @commands.command(name="jail", description="Jails a user", usage="jail <user>")
    @blacklist_check()
    @commands.has_permissions(administrator=True)
    async def jail(self, ctx, member: discord.Member):
        role = discord.utils.get(ctx.guild.roles, name="jailed")
        if not role:
            await ctx.guild.create_role(name="jailed")
        jail = discord.utils.get(ctx.guild.text_channels, name="jail")
        if not jail:
            try:
                overwrites = {
                    ctx.guild.default_role: discord.PermissionOverwrite(read_messages=False, send_messages=False),
                    ctx.guild.me: discord.PermissionOverwrite(read_messages=True)
                }            
                jail = await ctx.guild.create_text_channel("jail", overwrites=overwrites)
                await ctx.send(embed = discord.Embed(description=f"{ctx.author.mention}: created the **join** channel {jail.mention}",color=self.good))
            except discord.Forbidden:
                return await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: i am **missing** the `manage channels` permission", color=self.warn))

        for channel in ctx.guild.channels:
            if channel.name == "jail":
                perms = channel.overwrites_for(member)
                perms.send_messages = True
                perms.read_messages = True
                await channel.set_permissions(member, overwrite=perms)
            else:
                perms = channel.overwrites_for(member)
                perms.send_messages = False
                perms.read_messages = False
                perms.view_channel = False
                await channel.set_permissions(member, overwrite=perms)

        role = discord.utils.get(ctx.guild.roles, name="jailed")
        await member.add_roles(role)

        await jail.send(content=member.mention, embed=discord.Embed(title="", description="you been put in jail wait until your free", color=self.color))
        await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: **{member}** has been jailed", color=self.good))
    
    @jail.error
    async def jail_error(self, ctx, error):
        if isinstance(error, commands.MissingPermissions):
            return await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: **{ctx.invoked_with}** requires the `administrator` permission", color=self.warn))
    
    @commands.command(name="unjail", description="Unjails a user", usage="unjail <user>",  aliases=["free"])
    @blacklist_check()
    @commands.has_permissions(administrator=True)
    async def unjail(self, ctx, member: discord.Member):
        role = discord.utils.get(ctx.guild.roles, name="jailed")
        for channel in ctx.guild.channels:
            if channel.name == "jail":
                perms = channel.overwrites_for(member)
                perms.send_messages = None
                perms.read_messages = None
                await channel.set_permissions(member, overwrite=perms)
            else:
                perms = channel.overwrites_for(member)
                perms.send_messages = None
                perms.read_messages = None
                perms.view_channel = None
                await channel.set_permissions(member, overwrite=perms)
        role = discord.utils.get(ctx.guild.roles, name="jailed")
        await member.remove_roles(role)
        await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: **{member}** has been unjailed", color=self.good))
    
    @unjail.error
    async def unjail_error(self, ctx, error):
        if isinstance(error, commands.MissingPermissions):
            return await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: **{ctx.invoked_with}** requires the `administrator` permission", color=self.warn))

def setup(bot):
    bot.add_cog(mod(bot))#well uh i did enough for now ima hop off vsc cya 
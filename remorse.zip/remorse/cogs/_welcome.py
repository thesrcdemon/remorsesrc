# Imports
import discord
import os, math, pymongo, asyncio
from colorama import Fore
import time
from discord.ext import commands, tasks
import typing 
import aiohttp
from discord.ext import *
import functools
import random
import discord
import orjson
import json
import requests
import pymongo
import io, datetime
import sqlite3

mongodb = pymongo.MongoClient('mongodb+srv://forge:forge@trace.ltzwf.mongodb.net/discord?retryWrites=true&w=majority')
blacklist = mongodb.get_database("discord").get_collection("blacklists")

def blacklist_check():
    def predicate(ctx):
        author_id = ctx.author.id
        if blacklist.find_one({'user_id': author_id}):
            return False
        return True
    return commands.check(predicate)
class welcome(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.color = 0x2f3136
        self.good = discord.Colour.from_rgb(164, 235, 120)                                                                
        self.warn = discord.Colour.from_rgb(255,172,28)
        print(f"{Fore.CYAN}[Status] Cog Loaded: Welcome" + Fore.RESET)
    
    @commands.Cog.listener()
    async def on_member_join(self, member):
        db = sqlite3.connect('main.sqlite')
        cursor = db.cursor()
        cursor.execute(f"SELECT channel_id FROM main WHERE guild_id = {member.guild.id}")
        result = cursor.fetchone()
        if result is None:
            return
        else:
            cursor.execute(f"SELECT msg FROM main WHERE guild_id = {member.guild.id}")
            result1 = cursor.fetchone()
            members = len(list(member.guild.members))
            mention = member.mention
            user = member
            guild = member.guild
            name = member.name
            embed = discord.Embed(colour=self.color, description=str(result1[0]).format(members=members, mention=mention, user=user, guild=guild, name=name))
            embed.set_thumbnail(url=f"{member.avatar.url}")
            embed.set_footer(text=f"your the {members}th member!!")

            channel = self.bot.get_channel(id=int(result[0]))
            await channel.send(f'{member.mention}', embed=embed)


    @commands.group(aliases=['wlc', 'welc'], invoke_without_command=True)
    @commands.has_permissions(manage_channels=True)
    @blacklist_check()
    async def welcome(self, ctx):
        embed = discord.Embed(title="Command: welcome", description="set up a welcome message for when new members join up",color=self.color, timestamp=ctx.message.created_at)
        embed.add_field(name="Sub Commands",value="```,welcome channel\n,welcome message\n,welcome variables```",inline=False)
        embed.add_field(name="Aliases",value="wlc, welc")
        embed.add_field(name="Permissions", value="Manage Channels")
        embed.add_field(name="Arguments", value="Subcommand, Channel, Message")
        embed.add_field(name="Command Usage", value="```Syntax: ,welcome [subcommand] <channel> <message>\nExample: ,welcome channel #general```", inline=False)
        embed.set_author(name="remorse help", icon_url=ctx.author.avatar.url)
        embed.set_footer(text="Command Module: Welcome")
        await ctx.send(embed=embed)
    
    @welcome.error
    async def welcome_error(self, ctx, error):
        if isinstance(error, commands.MissingPermissions):
            return await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: **welcome** requires the `manage channels` permission", color=self.warn))


    @welcome.command(aliases=['chan', 'c'])
    @commands.has_permissions(manage_channels=True)
    @blacklist_check()
    async def channel(self, ctx, channel:discord.TextChannel):
        #
        db = sqlite3.connect('main.sqlite')
        cursor = db.cursor()
        cursor.execute(f"SELECT channel_id FROM main WHERE guild_id = {ctx.guild.id}")
        result = cursor.fetchone()
        if result is None:
            sql = ("INSERT INTO main(guild_id, channel_id) VALUES(?,?)")
            val = (ctx.guild.id, channel.id)
            await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: welcome channel set to {channel.mention}", color=self.good))
        elif result is not None:
            sql = ("UPDATE main SET channel_id = ? WHERE guild_id = ?")
            val = (channel.id, ctx.guild.id)
            await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: welcome channel set to {channel.mention}", color=self.good))
            cursor.execute(sql, val)
            db.commit()
            cursor.close()
            db.close()

    @welcome.command(aliases=['msg', 'm'])
    @commands.has_permissions(manage_channels=True)
    @blacklist_check()
    async def message(self, ctx, *, text):
        #
        db = sqlite3.connect('main.sqlite')
        cursor = db.cursor()
        cursor.execute(f"SELECT msg FROM main WHERE guild_id = {ctx.guild.id}")
        result = cursor.fetchone()
        if result is None:
            #
            sql = ("INSERT INTO main(guild_id, msg) VALUES(?,?)")
            val = (ctx.guild.id, text)
            await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: welcome message set to:\n\n```{text}```", color=self.good))
        elif result is not None:
            sql = ("UPDATE main SET msg = ? WHERE guild_id = ?")
            val = (text, ctx.guild.id)
            await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: welcome message updated to:\n\n```{text}```", color=self.good))
            cursor.execute(sql, val)
            db.commit()
            cursor.close()
            db.close()
    
    @welcome.command()
    @commands.has_permissions(manage_channels=True)
    @blacklist_check()
    async def variables(self, ctx):
        embed = discord.Embed(title="welcome variables",description="{members} —  guild membercount\n{user} —  user name and discriminator\n{guild} — guild username\n{mention} — user mention\n{name} — member name", color=self.color)
        await ctx.send(embed=embed)

def setup(bot):
    bot.add_cog(welcome(bot))
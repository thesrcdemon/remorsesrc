import discord
from discord.ext import commands
import logging
import pymongo

mongodb = pymongo.MongoClient('mongodb+srv://forge:forge@trace.ltzwf.mongodb.net/discord?retryWrites=true&w=majority')
db = mongodb.get_database("discord").get_collection("welcome")
blacklist = mongodb.get_database("discord").get_collection("blacklist")

class WelcomeEvents(commands.Cog):
    def __init__(self, client):
        self.client = client
        print(f'[\x1b[38;5;213mLOG\x1b[38;5;15m] Loaded COG [\x1b[38;5;213mWelcome\x1b[38;5;15m]')

    @commands.Cog.listener()
    async def on_member_join(self, user):
        try:
            guild = user.guild
            goodbyetoggle1 = db.find_one({"guild_id": guild.id})['welcome_toggle']
            goodbyetoggle2 = db.find_one({"guild_id": guild.id})['welcome_embed_toggle']
            channel1 = db.find_one({"guild_id": guild.id})['welcome_channel']
            message1 = db.find_one({"guild_id": guild.id})['welcome_message']

            if goodbyetoggle2 == 'Enabled':
                
                channel = db.find_one({"guild_id": guild.id})['welcome_channel']
                message = db.find_one({"guild_id": guild.id})['welcome_message']
                title = db.find_one({"guild_id": guild.id})['welcome_embed_title']
                colorr = db.find_one({"guild_id": guild.id})['welcome_embed_color']
                color = int(colorr, 0)

                if "{user.id}" in message:
                        message = message.replace("{user.id}", "%s" % (user.id))
                if "{user.mention}" in message:
                    message = message.replace("{user.mention}", "%s" % (user.mention))
                if "{user.tag}" in message:
                    message = message.replace("{user.tag}", "%s" % (user.discriminator))
                if "{user.name}" in message:
                    message = message.replace("{user.name}", "%s" % (user.name))
                if "{user.avatar}" in message:
                    message = message.replace("{user.avatar}", "%s" % (user.avatar_url))
                if "{server.name}" in message:
                    message = message.replace("{server.name}", "%s" % (user.guild.name)) 
                if "{server.membercount}" in message:
                    message = message.replace("{server.membercount}", "%s" % (user.guild.member_count))          
                if "{server.icon}" in message:
                    message = message.replace("{server.icon}", "%s" % (user.guild.icon_url))

                if "{user.id}" in title:
                        title = title.replace("{user.id}", "%s" % (user.id))
                if "{user.mention}" in title:
                    title = title.replace("{user.mention}", "%s" % (user.mention))
                if "{user.tag}" in title:
                    title = title.replace("{user.tag}", "%s" % (user.discriminator))
                if "{user.name}" in title:
                    title = title.replace("{user.name}", "%s" % (user.name))
                if "{user.avatar}" in title:
                    title = title.replace("{user.avatar}", "%s" % (user.avatar_url))
                if "{server.name}" in title:
                    title = title.replace("{server.name}", "%s" % (user.guild.name)) 
                if "{server.membercount}" in title:
                    title = title.replace("{server.membercount}", "%s" % (user.guild.member_count))          
                if "{server.icon}" in title:
                    title = title.replace("{server.icon}", "%s" % (user.guild.icon_url))

                if title == None:
                    embed=discord.Embed(description=f"{message}", color=color)
                    channelsend = self.client.get_channel(channel)
                    await channelsend.send(embed=embed)
                    return
        
                if message == None:
                    embed=discord.Embed(title=f"{title}", color=color)
                    channelsend = self.client.get_channel(channel)
                    await channelsend.send(embed=embed)
                    return

                if message and title == None:
                    channelsend = self.client.get_channel(channel)
                    await channelsend.send(message)
                    return

                embed=discord.Embed(title=f'{title}', description=f"{message}", color=color)
                channelsend = self.client.get_channel(channel)
                await channelsend.send(embed=embed)
                return


            if goodbyetoggle1 == 'Enabled':
                message = db.find_one({"guild_id": guild.id})['message']
                title = db.find_one({"guild_id": guild.id})['title']
                colorr = db.find_one({"guild_id": guild.id})['color']
                color = int(colorr, 0)

                if "{user.id}" in message:
                        message = message.replace("{user.id}", "%s" % (user.id))
                if "{user.mention}" in message:
                    message = message.replace("{user.mention}", "%s" % (user.mention))
                if "{user.tag}" in message:
                    message = message.replace("{user.tag}", "%s" % (user.discriminator))
                if "{user.name}" in message:
                    message = message.replace("{user.name}", "%s" % (user.name))
                if "{user.avatar}" in message:
                    message = message.replace("{user.avatar}", "%s" % (user.avatar_url))
                if "{server.name}" in message:
                    message = message.replace("{server.name}", "%s" % (user.guild.name)) 
                if "{server.membercount}" in message:
                    message = message.replace("{server.membercount}", "%s" % (user.guild.member_count))          
                if "{server.icon}" in message:
                    message = message.replace("{server.icon}", "%s" % (user.guild.icon_url))

                if "{user.id}" in title:
                        title = title.replace("{user.id}", "%s" % (user.id))
                if "{user.mention}" in title:
                    title = title.replace("{user.mention}", "%s" % (user.mention))
                if "{user.tag}" in title:
                    title = title.replace("{user.tag}", "%s" % (user.discriminator))
                if "{user.name}" in title:
                    title = title.replace("{user.name}", "%s" % (user.name))
                if "{user.avatar}" in title:
                    title = title.replace("{user.avatar}", "%s" % (user.avatar_url))
                if "{server.name}" in title:
                    title = title.replace("{server.name}", "%s" % (user.guild.name)) 
                if "{server.membercount}" in title:
                    title = title.replace("{server.membercount}", "%s" % (user.guild.member_count))          
                if "{server.icon}" in title:
                    title = title.replace("{server.icon}", "%s" % (user.guild.icon_url))
                channel1 = db.find_one({"guild_id": guild.id})['channel']
                channelsend = self.client.get_channel(channel1)
                await channelsend.send(message)
                return

        except Exception as e:
            print(e)

def setup(client):
    client.add_cog(WelcomeEvents(client))